gdjs.CylinderCode = {};
gdjs.CylinderCode.localVariables = [];
gdjs.CylinderCode.GDAnswerButtonObjects1_2final = [];

gdjs.CylinderCode.GDCylinderModelObjects1= [];
gdjs.CylinderCode.GDCylinderModelObjects2= [];
gdjs.CylinderCode.GDheightObjects1= [];
gdjs.CylinderCode.GDheightObjects2= [];
gdjs.CylinderCode.GDRadiusObjects1= [];
gdjs.CylinderCode.GDRadiusObjects2= [];
gdjs.CylinderCode.GDAnswerObjects1= [];
gdjs.CylinderCode.GDAnswerObjects2= [];
gdjs.CylinderCode.GDunitObjects1= [];
gdjs.CylinderCode.GDunitObjects2= [];
gdjs.CylinderCode.GDBackNewButtonObjects1= [];
gdjs.CylinderCode.GDBackNewButtonObjects2= [];
gdjs.CylinderCode.GDControlsObjects1= [];
gdjs.CylinderCode.GDControlsObjects2= [];
gdjs.CylinderCode.GDAnswerButtonObjects1= [];
gdjs.CylinderCode.GDAnswerButtonObjects2= [];


gdjs.CylinderCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Radius"), gdjs.CylinderCode.GDRadiusObjects1);
gdjs.copyArray(runtimeScene.getObjects("height"), gdjs.CylinderCode.GDheightObjects1);
gdjs.CylinderCode.GDAnswerButtonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
{isConditionTrue_1 = ((gdjs.evtTools.common.toNumber((( gdjs.CylinderCode.GDheightObjects1.length === 0 ) ? "" :gdjs.CylinderCode.GDheightObjects1[0].getBehavior("Text").getText()))) > 0);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = ((gdjs.evtTools.common.toNumber((( gdjs.CylinderCode.GDRadiusObjects1.length === 0 ) ? "" :gdjs.CylinderCode.GDRadiusObjects1[0].getBehavior("Text").getText()))) > 0);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.CylinderCode.GDAnswerButtonObjects1_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
isConditionTrue_2 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("AnswerButton"), gdjs.CylinderCode.GDAnswerButtonObjects2);
for (var i = 0, k = 0, l = gdjs.CylinderCode.GDAnswerButtonObjects2.length;i<l;++i) {
    if ( gdjs.CylinderCode.GDAnswerButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_2 = true;
        gdjs.CylinderCode.GDAnswerButtonObjects2[k] = gdjs.CylinderCode.GDAnswerButtonObjects2[i];
        ++k;
    }
}
gdjs.CylinderCode.GDAnswerButtonObjects2.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.CylinderCode.GDAnswerButtonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.CylinderCode.GDAnswerButtonObjects1_2final.indexOf(gdjs.CylinderCode.GDAnswerButtonObjects2[j]) === -1 )
            gdjs.CylinderCode.GDAnswerButtonObjects1_2final.push(gdjs.CylinderCode.GDAnswerButtonObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.CylinderCode.GDAnswerButtonObjects1_2final, gdjs.CylinderCode.GDAnswerButtonObjects1);
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Answer"), gdjs.CylinderCode.GDAnswerObjects1);
gdjs.copyArray(runtimeScene.getObjects("CylinderModel"), gdjs.CylinderCode.GDCylinderModelObjects1);
/* Reuse gdjs.CylinderCode.GDRadiusObjects1 */
/* Reuse gdjs.CylinderCode.GDheightObjects1 */
gdjs.copyArray(runtimeScene.getObjects("unit"), gdjs.CylinderCode.GDunitObjects1);
{for(var i = 0, len = gdjs.CylinderCode.GDCylinderModelObjects1.length ;i < len;++i) {
    gdjs.CylinderCode.GDCylinderModelObjects1[i].getBehavior("Object3D").setDepth(gdjs.evtTools.common.toNumber((( gdjs.CylinderCode.GDRadiusObjects1.length === 0 ) ? "" :gdjs.CylinderCode.GDRadiusObjects1[0].getBehavior("Text").getText())) * 2);
}
}{for(var i = 0, len = gdjs.CylinderCode.GDCylinderModelObjects1.length ;i < len;++i) {
    gdjs.CylinderCode.GDCylinderModelObjects1[i].getBehavior("Scale").setScaleX(gdjs.evtTools.common.toNumber((( gdjs.CylinderCode.GDRadiusObjects1.length === 0 ) ? "" :gdjs.CylinderCode.GDRadiusObjects1[0].getBehavior("Text").getText())) * 2);
}
}{for(var i = 0, len = gdjs.CylinderCode.GDCylinderModelObjects1.length ;i < len;++i) {
    gdjs.CylinderCode.GDCylinderModelObjects1[i].getBehavior("Scale").setScaleY(gdjs.evtTools.common.toNumber((( gdjs.CylinderCode.GDRadiusObjects1.length === 0 ) ? "" :gdjs.CylinderCode.GDRadiusObjects1[0].getBehavior("Text").getText())) * 2);
}
}{for(var i = 0, len = gdjs.CylinderCode.GDAnswerObjects1.length ;i < len;++i) {
    gdjs.CylinderCode.GDAnswerObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.common.roundTo(gdjs.evtTools.common.toNumber((( gdjs.CylinderCode.GDRadiusObjects1.length === 0 ) ? "" :gdjs.CylinderCode.GDRadiusObjects1[0].getBehavior("Text").getText())) * (gdjs.evtTools.common.toNumber((( gdjs.CylinderCode.GDRadiusObjects1.length === 0 ) ? "" :gdjs.CylinderCode.GDRadiusObjects1[0].getBehavior("Text").getText()))) * 3.141 * (gdjs.evtTools.common.toNumber((( gdjs.CylinderCode.GDheightObjects1.length === 0 ) ? "" :gdjs.CylinderCode.GDheightObjects1[0].getBehavior("Text").getText()))), 3)) + (( gdjs.CylinderCode.GDunitObjects1.length === 0 ) ? "" :gdjs.CylinderCode.GDunitObjects1[0].getBehavior("Text").getText()) + ((gdjs.CylinderCode.GDunitObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.CylinderCode.GDunitObjects1[0].getVariables()).getFromIndex(0).getAsString());
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CylinderModel"), gdjs.CylinderCode.GDCylinderModelObjects1);
{for(var i = 0, len = gdjs.CylinderCode.GDCylinderModelObjects1.length ;i < len;++i) {
    gdjs.CylinderCode.GDCylinderModelObjects1[i].getBehavior("Object3D").turnAroundX(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CylinderModel"), gdjs.CylinderCode.GDCylinderModelObjects1);
{for(var i = 0, len = gdjs.CylinderCode.GDCylinderModelObjects1.length ;i < len;++i) {
    gdjs.CylinderCode.GDCylinderModelObjects1[i].getBehavior("Object3D").turnAroundY(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CylinderModel"), gdjs.CylinderCode.GDCylinderModelObjects1);
{for(var i = 0, len = gdjs.CylinderCode.GDCylinderModelObjects1.length ;i < len;++i) {
    gdjs.CylinderCode.GDCylinderModelObjects1[i].getBehavior("Object3D").turnAroundY(-(3));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CylinderModel"), gdjs.CylinderCode.GDCylinderModelObjects1);
{for(var i = 0, len = gdjs.CylinderCode.GDCylinderModelObjects1.length ;i < len;++i) {
    gdjs.CylinderCode.GDCylinderModelObjects1[i].getBehavior("Object3D").turnAroundX(-(3));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Dash");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CylinderModel"), gdjs.CylinderCode.GDCylinderModelObjects1);
{for(var i = 0, len = gdjs.CylinderCode.GDCylinderModelObjects1.length ;i < len;++i) {
    gdjs.CylinderCode.GDCylinderModelObjects1[i].getBehavior("Scale").setScaleX(gdjs.CylinderCode.GDCylinderModelObjects1[i].getBehavior("Scale").getScaleX() / (1.009));
}
}{for(var i = 0, len = gdjs.CylinderCode.GDCylinderModelObjects1.length ;i < len;++i) {
    gdjs.CylinderCode.GDCylinderModelObjects1[i].getBehavior("Scale").setScaleY(gdjs.CylinderCode.GDCylinderModelObjects1[i].getBehavior("Scale").getScaleY() / (1.009));
}
}{for(var i = 0, len = gdjs.CylinderCode.GDCylinderModelObjects1.length ;i < len;++i) {
    gdjs.CylinderCode.GDCylinderModelObjects1[i].getBehavior("Object3D").setScaleZ(gdjs.CylinderCode.GDCylinderModelObjects1[i].getBehavior("Object3D").getScaleZ() / (1.009));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Equal");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CylinderModel"), gdjs.CylinderCode.GDCylinderModelObjects1);
{for(var i = 0, len = gdjs.CylinderCode.GDCylinderModelObjects1.length ;i < len;++i) {
    gdjs.CylinderCode.GDCylinderModelObjects1[i].getBehavior("Scale").setScaleX(gdjs.CylinderCode.GDCylinderModelObjects1[i].getBehavior("Scale").getScaleX() * (1.009));
}
}{for(var i = 0, len = gdjs.CylinderCode.GDCylinderModelObjects1.length ;i < len;++i) {
    gdjs.CylinderCode.GDCylinderModelObjects1[i].getBehavior("Object3D").setScaleZ(gdjs.CylinderCode.GDCylinderModelObjects1[i].getBehavior("Object3D").getScaleZ() * (1.009));
}
}{for(var i = 0, len = gdjs.CylinderCode.GDCylinderModelObjects1.length ;i < len;++i) {
    gdjs.CylinderCode.GDCylinderModelObjects1[i].getBehavior("Scale").setScaleY(gdjs.CylinderCode.GDCylinderModelObjects1[i].getBehavior("Scale").getScaleY() * (1.009));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LShift");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CylinderModel"), gdjs.CylinderCode.GDCylinderModelObjects1);
{for(var i = 0, len = gdjs.CylinderCode.GDCylinderModelObjects1.length ;i < len;++i) {
    gdjs.CylinderCode.GDCylinderModelObjects1[i].getBehavior("Object3D").turnAroundZ(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LControl");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CylinderModel"), gdjs.CylinderCode.GDCylinderModelObjects1);
{for(var i = 0, len = gdjs.CylinderCode.GDCylinderModelObjects1.length ;i < len;++i) {
    gdjs.CylinderCode.GDCylinderModelObjects1[i].getBehavior("Object3D").turnAroundZ(-(3));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BackNewButton"), gdjs.CylinderCode.GDBackNewButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.CylinderCode.GDBackNewButtonObjects1.length;i<l;++i) {
    if ( gdjs.CylinderCode.GDBackNewButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.CylinderCode.GDBackNewButtonObjects1[k] = gdjs.CylinderCode.GDBackNewButtonObjects1[i];
        ++k;
    }
}
gdjs.CylinderCode.GDBackNewButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


};

gdjs.CylinderCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.CylinderCode.GDCylinderModelObjects1.length = 0;
gdjs.CylinderCode.GDCylinderModelObjects2.length = 0;
gdjs.CylinderCode.GDheightObjects1.length = 0;
gdjs.CylinderCode.GDheightObjects2.length = 0;
gdjs.CylinderCode.GDRadiusObjects1.length = 0;
gdjs.CylinderCode.GDRadiusObjects2.length = 0;
gdjs.CylinderCode.GDAnswerObjects1.length = 0;
gdjs.CylinderCode.GDAnswerObjects2.length = 0;
gdjs.CylinderCode.GDunitObjects1.length = 0;
gdjs.CylinderCode.GDunitObjects2.length = 0;
gdjs.CylinderCode.GDBackNewButtonObjects1.length = 0;
gdjs.CylinderCode.GDBackNewButtonObjects2.length = 0;
gdjs.CylinderCode.GDControlsObjects1.length = 0;
gdjs.CylinderCode.GDControlsObjects2.length = 0;
gdjs.CylinderCode.GDAnswerButtonObjects1.length = 0;
gdjs.CylinderCode.GDAnswerButtonObjects2.length = 0;

gdjs.CylinderCode.eventsList0(runtimeScene);
gdjs.CylinderCode.GDCylinderModelObjects1.length = 0;
gdjs.CylinderCode.GDCylinderModelObjects2.length = 0;
gdjs.CylinderCode.GDheightObjects1.length = 0;
gdjs.CylinderCode.GDheightObjects2.length = 0;
gdjs.CylinderCode.GDRadiusObjects1.length = 0;
gdjs.CylinderCode.GDRadiusObjects2.length = 0;
gdjs.CylinderCode.GDAnswerObjects1.length = 0;
gdjs.CylinderCode.GDAnswerObjects2.length = 0;
gdjs.CylinderCode.GDunitObjects1.length = 0;
gdjs.CylinderCode.GDunitObjects2.length = 0;
gdjs.CylinderCode.GDBackNewButtonObjects1.length = 0;
gdjs.CylinderCode.GDBackNewButtonObjects2.length = 0;
gdjs.CylinderCode.GDControlsObjects1.length = 0;
gdjs.CylinderCode.GDControlsObjects2.length = 0;
gdjs.CylinderCode.GDAnswerButtonObjects1.length = 0;
gdjs.CylinderCode.GDAnswerButtonObjects2.length = 0;


return;

}

gdjs['CylinderCode'] = gdjs.CylinderCode;
