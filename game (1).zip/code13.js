gdjs.Prism_32MenuCode = {};
gdjs.Prism_32MenuCode.localVariables = [];
gdjs.Prism_32MenuCode.GDIntroObjects1= [];
gdjs.Prism_32MenuCode.GDIntroObjects2= [];
gdjs.Prism_32MenuCode.GDDirectToCubeObjects1= [];
gdjs.Prism_32MenuCode.GDDirectToCubeObjects2= [];
gdjs.Prism_32MenuCode.GDDirectToTriangularPrismObjects1= [];
gdjs.Prism_32MenuCode.GDDirectToTriangularPrismObjects2= [];
gdjs.Prism_32MenuCode.GDDirectToCylinderObjects1= [];
gdjs.Prism_32MenuCode.GDDirectToCylinderObjects2= [];
gdjs.Prism_32MenuCode.GDDirectToPentagonalPrismObjects1= [];
gdjs.Prism_32MenuCode.GDDirectToPentagonalPrismObjects2= [];
gdjs.Prism_32MenuCode.GDDirectToHexagonalPrismObjects1= [];
gdjs.Prism_32MenuCode.GDDirectToHexagonalPrismObjects2= [];
gdjs.Prism_32MenuCode.GDBackNewButtonObjects1= [];
gdjs.Prism_32MenuCode.GDBackNewButtonObjects2= [];
gdjs.Prism_32MenuCode.GDControlsObjects1= [];
gdjs.Prism_32MenuCode.GDControlsObjects2= [];
gdjs.Prism_32MenuCode.GDAnswerButtonObjects1= [];
gdjs.Prism_32MenuCode.GDAnswerButtonObjects2= [];


gdjs.Prism_32MenuCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DirectToCube"), gdjs.Prism_32MenuCode.GDDirectToCubeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Prism_32MenuCode.GDDirectToCubeObjects1.length;i<l;++i) {
    if ( gdjs.Prism_32MenuCode.GDDirectToCubeObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Prism_32MenuCode.GDDirectToCubeObjects1[k] = gdjs.Prism_32MenuCode.GDDirectToCubeObjects1[i];
        ++k;
    }
}
gdjs.Prism_32MenuCode.GDDirectToCubeObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Square Pyramid", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DirectToTriangularPrism"), gdjs.Prism_32MenuCode.GDDirectToTriangularPrismObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Prism_32MenuCode.GDDirectToTriangularPrismObjects1.length;i<l;++i) {
    if ( gdjs.Prism_32MenuCode.GDDirectToTriangularPrismObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Prism_32MenuCode.GDDirectToTriangularPrismObjects1[k] = gdjs.Prism_32MenuCode.GDDirectToTriangularPrismObjects1[i];
        ++k;
    }
}
gdjs.Prism_32MenuCode.GDDirectToTriangularPrismObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Triangular Prism", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DirectToCylinder"), gdjs.Prism_32MenuCode.GDDirectToCylinderObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Prism_32MenuCode.GDDirectToCylinderObjects1.length;i<l;++i) {
    if ( gdjs.Prism_32MenuCode.GDDirectToCylinderObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Prism_32MenuCode.GDDirectToCylinderObjects1[k] = gdjs.Prism_32MenuCode.GDDirectToCylinderObjects1[i];
        ++k;
    }
}
gdjs.Prism_32MenuCode.GDDirectToCylinderObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Cylinder", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BackNewButton"), gdjs.Prism_32MenuCode.GDBackNewButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Prism_32MenuCode.GDBackNewButtonObjects1.length;i<l;++i) {
    if ( gdjs.Prism_32MenuCode.GDBackNewButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Prism_32MenuCode.GDBackNewButtonObjects1[k] = gdjs.Prism_32MenuCode.GDBackNewButtonObjects1[i];
        ++k;
    }
}
gdjs.Prism_32MenuCode.GDBackNewButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DirectToPentagonalPrism"), gdjs.Prism_32MenuCode.GDDirectToPentagonalPrismObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Prism_32MenuCode.GDDirectToPentagonalPrismObjects1.length;i<l;++i) {
    if ( gdjs.Prism_32MenuCode.GDDirectToPentagonalPrismObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Prism_32MenuCode.GDDirectToPentagonalPrismObjects1[k] = gdjs.Prism_32MenuCode.GDDirectToPentagonalPrismObjects1[i];
        ++k;
    }
}
gdjs.Prism_32MenuCode.GDDirectToPentagonalPrismObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Pentagonal Prism", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DirectToHexagonalPrism"), gdjs.Prism_32MenuCode.GDDirectToHexagonalPrismObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Prism_32MenuCode.GDDirectToHexagonalPrismObjects1.length;i<l;++i) {
    if ( gdjs.Prism_32MenuCode.GDDirectToHexagonalPrismObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Prism_32MenuCode.GDDirectToHexagonalPrismObjects1[k] = gdjs.Prism_32MenuCode.GDDirectToHexagonalPrismObjects1[i];
        ++k;
    }
}
gdjs.Prism_32MenuCode.GDDirectToHexagonalPrismObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Hexagonal Prism", false);
}}

}


};

gdjs.Prism_32MenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Prism_32MenuCode.GDIntroObjects1.length = 0;
gdjs.Prism_32MenuCode.GDIntroObjects2.length = 0;
gdjs.Prism_32MenuCode.GDDirectToCubeObjects1.length = 0;
gdjs.Prism_32MenuCode.GDDirectToCubeObjects2.length = 0;
gdjs.Prism_32MenuCode.GDDirectToTriangularPrismObjects1.length = 0;
gdjs.Prism_32MenuCode.GDDirectToTriangularPrismObjects2.length = 0;
gdjs.Prism_32MenuCode.GDDirectToCylinderObjects1.length = 0;
gdjs.Prism_32MenuCode.GDDirectToCylinderObjects2.length = 0;
gdjs.Prism_32MenuCode.GDDirectToPentagonalPrismObjects1.length = 0;
gdjs.Prism_32MenuCode.GDDirectToPentagonalPrismObjects2.length = 0;
gdjs.Prism_32MenuCode.GDDirectToHexagonalPrismObjects1.length = 0;
gdjs.Prism_32MenuCode.GDDirectToHexagonalPrismObjects2.length = 0;
gdjs.Prism_32MenuCode.GDBackNewButtonObjects1.length = 0;
gdjs.Prism_32MenuCode.GDBackNewButtonObjects2.length = 0;
gdjs.Prism_32MenuCode.GDControlsObjects1.length = 0;
gdjs.Prism_32MenuCode.GDControlsObjects2.length = 0;
gdjs.Prism_32MenuCode.GDAnswerButtonObjects1.length = 0;
gdjs.Prism_32MenuCode.GDAnswerButtonObjects2.length = 0;

gdjs.Prism_32MenuCode.eventsList0(runtimeScene);
gdjs.Prism_32MenuCode.GDIntroObjects1.length = 0;
gdjs.Prism_32MenuCode.GDIntroObjects2.length = 0;
gdjs.Prism_32MenuCode.GDDirectToCubeObjects1.length = 0;
gdjs.Prism_32MenuCode.GDDirectToCubeObjects2.length = 0;
gdjs.Prism_32MenuCode.GDDirectToTriangularPrismObjects1.length = 0;
gdjs.Prism_32MenuCode.GDDirectToTriangularPrismObjects2.length = 0;
gdjs.Prism_32MenuCode.GDDirectToCylinderObjects1.length = 0;
gdjs.Prism_32MenuCode.GDDirectToCylinderObjects2.length = 0;
gdjs.Prism_32MenuCode.GDDirectToPentagonalPrismObjects1.length = 0;
gdjs.Prism_32MenuCode.GDDirectToPentagonalPrismObjects2.length = 0;
gdjs.Prism_32MenuCode.GDDirectToHexagonalPrismObjects1.length = 0;
gdjs.Prism_32MenuCode.GDDirectToHexagonalPrismObjects2.length = 0;
gdjs.Prism_32MenuCode.GDBackNewButtonObjects1.length = 0;
gdjs.Prism_32MenuCode.GDBackNewButtonObjects2.length = 0;
gdjs.Prism_32MenuCode.GDControlsObjects1.length = 0;
gdjs.Prism_32MenuCode.GDControlsObjects2.length = 0;
gdjs.Prism_32MenuCode.GDAnswerButtonObjects1.length = 0;
gdjs.Prism_32MenuCode.GDAnswerButtonObjects2.length = 0;


return;

}

gdjs['Prism_32MenuCode'] = gdjs.Prism_32MenuCode;
