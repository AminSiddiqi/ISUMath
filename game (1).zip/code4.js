gdjs.Pentagonal_32PyramidCode = {};
gdjs.Pentagonal_32PyramidCode.localVariables = [];
gdjs.Pentagonal_32PyramidCode.GDAnswerButtonObjects1_2final = [];

gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1= [];
gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects2= [];
gdjs.Pentagonal_32PyramidCode.GDSideLengthObjects1= [];
gdjs.Pentagonal_32PyramidCode.GDSideLengthObjects2= [];
gdjs.Pentagonal_32PyramidCode.GDLengthObjects1= [];
gdjs.Pentagonal_32PyramidCode.GDLengthObjects2= [];
gdjs.Pentagonal_32PyramidCode.GDAnswerObjects1= [];
gdjs.Pentagonal_32PyramidCode.GDAnswerObjects2= [];
gdjs.Pentagonal_32PyramidCode.GDunitObjects1= [];
gdjs.Pentagonal_32PyramidCode.GDunitObjects2= [];
gdjs.Pentagonal_32PyramidCode.GDNew3DModelObjects1= [];
gdjs.Pentagonal_32PyramidCode.GDNew3DModelObjects2= [];
gdjs.Pentagonal_32PyramidCode.GDBackNewButtonObjects1= [];
gdjs.Pentagonal_32PyramidCode.GDBackNewButtonObjects2= [];
gdjs.Pentagonal_32PyramidCode.GDControlsObjects1= [];
gdjs.Pentagonal_32PyramidCode.GDControlsObjects2= [];
gdjs.Pentagonal_32PyramidCode.GDAnswerButtonObjects1= [];
gdjs.Pentagonal_32PyramidCode.GDAnswerButtonObjects2= [];


gdjs.Pentagonal_32PyramidCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Length"), gdjs.Pentagonal_32PyramidCode.GDLengthObjects1);
gdjs.copyArray(runtimeScene.getObjects("SideLength"), gdjs.Pentagonal_32PyramidCode.GDSideLengthObjects1);
gdjs.Pentagonal_32PyramidCode.GDAnswerButtonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
{isConditionTrue_1 = ((gdjs.evtTools.common.toNumber(((( gdjs.Pentagonal_32PyramidCode.GDSideLengthObjects1.length === 0 ) ? "" :gdjs.Pentagonal_32PyramidCode.GDSideLengthObjects1[0].getBehavior("Text").getText())))) > 0);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = ((gdjs.evtTools.common.toNumber(((( gdjs.Pentagonal_32PyramidCode.GDLengthObjects1.length === 0 ) ? "" :gdjs.Pentagonal_32PyramidCode.GDLengthObjects1[0].getBehavior("Text").getText())))) > 0);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.Pentagonal_32PyramidCode.GDAnswerButtonObjects1_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
isConditionTrue_2 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("AnswerButton"), gdjs.Pentagonal_32PyramidCode.GDAnswerButtonObjects2);
for (var i = 0, k = 0, l = gdjs.Pentagonal_32PyramidCode.GDAnswerButtonObjects2.length;i<l;++i) {
    if ( gdjs.Pentagonal_32PyramidCode.GDAnswerButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_2 = true;
        gdjs.Pentagonal_32PyramidCode.GDAnswerButtonObjects2[k] = gdjs.Pentagonal_32PyramidCode.GDAnswerButtonObjects2[i];
        ++k;
    }
}
gdjs.Pentagonal_32PyramidCode.GDAnswerButtonObjects2.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Pentagonal_32PyramidCode.GDAnswerButtonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Pentagonal_32PyramidCode.GDAnswerButtonObjects1_2final.indexOf(gdjs.Pentagonal_32PyramidCode.GDAnswerButtonObjects2[j]) === -1 )
            gdjs.Pentagonal_32PyramidCode.GDAnswerButtonObjects1_2final.push(gdjs.Pentagonal_32PyramidCode.GDAnswerButtonObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Pentagonal_32PyramidCode.GDAnswerButtonObjects1_2final, gdjs.Pentagonal_32PyramidCode.GDAnswerButtonObjects1);
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Answer"), gdjs.Pentagonal_32PyramidCode.GDAnswerObjects1);
/* Reuse gdjs.Pentagonal_32PyramidCode.GDLengthObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Pentagonprism"), gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1);
/* Reuse gdjs.Pentagonal_32PyramidCode.GDSideLengthObjects1 */
gdjs.copyArray(runtimeScene.getObjects("unit"), gdjs.Pentagonal_32PyramidCode.GDunitObjects1);
{for(var i = 0, len = gdjs.Pentagonal_32PyramidCode.GDAnswerObjects1.length ;i < len;++i) {
    gdjs.Pentagonal_32PyramidCode.GDAnswerObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.common.roundTo(gdjs.evtTools.common.toNumber((( gdjs.Pentagonal_32PyramidCode.GDSideLengthObjects1.length === 0 ) ? "" :gdjs.Pentagonal_32PyramidCode.GDSideLengthObjects1[0].getBehavior("Text").getText())) * gdjs.evtTools.common.toNumber((( gdjs.Pentagonal_32PyramidCode.GDSideLengthObjects1.length === 0 ) ? "" :gdjs.Pentagonal_32PyramidCode.GDSideLengthObjects1[0].getBehavior("Text").getText())) * gdjs.evtTools.common.toNumber((( gdjs.Pentagonal_32PyramidCode.GDLengthObjects1.length === 0 ) ? "" :gdjs.Pentagonal_32PyramidCode.GDLengthObjects1[0].getBehavior("Text").getText())) * 0.25 * (Math.sqrt(5 * (5 + 2 * Math.sqrt(5)) / 3)), 3)) + (( gdjs.Pentagonal_32PyramidCode.GDunitObjects1.length === 0 ) ? "" :gdjs.Pentagonal_32PyramidCode.GDunitObjects1[0].getBehavior("Text").getText()) + ((gdjs.Pentagonal_32PyramidCode.GDunitObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Pentagonal_32PyramidCode.GDunitObjects1[0].getVariables()).getFromIndex(0).getAsString());
}
}{for(var i = 0, len = gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1.length ;i < len;++i) {
    gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1[i].getBehavior("Resizable").setSize(gdjs.evtTools.common.toNumber(((( gdjs.Pentagonal_32PyramidCode.GDSideLengthObjects1.length === 0 ) ? "" :gdjs.Pentagonal_32PyramidCode.GDSideLengthObjects1[0].getBehavior("Text").getText()))) * 10, gdjs.evtTools.common.toNumber(((( gdjs.Pentagonal_32PyramidCode.GDSideLengthObjects1.length === 0 ) ? "" :gdjs.Pentagonal_32PyramidCode.GDSideLengthObjects1[0].getBehavior("Text").getText()))) * 10);
}
}{for(var i = 0, len = gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1.length ;i < len;++i) {
    gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1[i].getBehavior("Object3D").setDepth(gdjs.evtTools.common.toNumber((( gdjs.Pentagonal_32PyramidCode.GDLengthObjects1.length === 0 ) ? "" :gdjs.Pentagonal_32PyramidCode.GDLengthObjects1[0].getBehavior("Text").getText())) * 10);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Pentagonprism"), gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1);
{for(var i = 0, len = gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1.length ;i < len;++i) {
    gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1[i].getBehavior("Object3D").turnAroundX(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Pentagonprism"), gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1);
{for(var i = 0, len = gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1.length ;i < len;++i) {
    gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1[i].getBehavior("Object3D").turnAroundY(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Pentagonprism"), gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1);
{for(var i = 0, len = gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1.length ;i < len;++i) {
    gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1[i].getBehavior("Object3D").turnAroundY(-(3));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Pentagonprism"), gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1);
{for(var i = 0, len = gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1.length ;i < len;++i) {
    gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1[i].getBehavior("Object3D").turnAroundX(-(3));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Dash");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Pentagonprism"), gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1);
{for(var i = 0, len = gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1.length ;i < len;++i) {
    gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1[i].getBehavior("Scale").setScaleX(gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1[i].getBehavior("Scale").getScaleX() / (1.009));
}
}{for(var i = 0, len = gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1.length ;i < len;++i) {
    gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1[i].getBehavior("Scale").setScaleY(gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1[i].getBehavior("Scale").getScaleY() / (1.009));
}
}{for(var i = 0, len = gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1.length ;i < len;++i) {
    gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1[i].getBehavior("Object3D").setScaleZ(gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1[i].getBehavior("Object3D").getScaleZ() / (1.009));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Equal");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Pentagonprism"), gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1);
{for(var i = 0, len = gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1.length ;i < len;++i) {
    gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1[i].getBehavior("Scale").setScaleX(gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1[i].getBehavior("Scale").getScaleX() * (1.009));
}
}{for(var i = 0, len = gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1.length ;i < len;++i) {
    gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1[i].getBehavior("Object3D").setScaleZ(gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1[i].getBehavior("Object3D").getScaleZ() * (1.009));
}
}{for(var i = 0, len = gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1.length ;i < len;++i) {
    gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1[i].getBehavior("Scale").setScaleY(gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1[i].getBehavior("Scale").getScaleY() * (1.009));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LShift");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Pentagonprism"), gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1);
{for(var i = 0, len = gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1.length ;i < len;++i) {
    gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1[i].getBehavior("Object3D").turnAroundZ(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LControl");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Pentagonprism"), gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1);
{for(var i = 0, len = gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1.length ;i < len;++i) {
    gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1[i].getBehavior("Object3D").turnAroundZ(-(3));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BackNewButton"), gdjs.Pentagonal_32PyramidCode.GDBackNewButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Pentagonal_32PyramidCode.GDBackNewButtonObjects1.length;i<l;++i) {
    if ( gdjs.Pentagonal_32PyramidCode.GDBackNewButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Pentagonal_32PyramidCode.GDBackNewButtonObjects1[k] = gdjs.Pentagonal_32PyramidCode.GDBackNewButtonObjects1[i];
        ++k;
    }
}
gdjs.Pentagonal_32PyramidCode.GDBackNewButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


};

gdjs.Pentagonal_32PyramidCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1.length = 0;
gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects2.length = 0;
gdjs.Pentagonal_32PyramidCode.GDSideLengthObjects1.length = 0;
gdjs.Pentagonal_32PyramidCode.GDSideLengthObjects2.length = 0;
gdjs.Pentagonal_32PyramidCode.GDLengthObjects1.length = 0;
gdjs.Pentagonal_32PyramidCode.GDLengthObjects2.length = 0;
gdjs.Pentagonal_32PyramidCode.GDAnswerObjects1.length = 0;
gdjs.Pentagonal_32PyramidCode.GDAnswerObjects2.length = 0;
gdjs.Pentagonal_32PyramidCode.GDunitObjects1.length = 0;
gdjs.Pentagonal_32PyramidCode.GDunitObjects2.length = 0;
gdjs.Pentagonal_32PyramidCode.GDNew3DModelObjects1.length = 0;
gdjs.Pentagonal_32PyramidCode.GDNew3DModelObjects2.length = 0;
gdjs.Pentagonal_32PyramidCode.GDBackNewButtonObjects1.length = 0;
gdjs.Pentagonal_32PyramidCode.GDBackNewButtonObjects2.length = 0;
gdjs.Pentagonal_32PyramidCode.GDControlsObjects1.length = 0;
gdjs.Pentagonal_32PyramidCode.GDControlsObjects2.length = 0;
gdjs.Pentagonal_32PyramidCode.GDAnswerButtonObjects1.length = 0;
gdjs.Pentagonal_32PyramidCode.GDAnswerButtonObjects2.length = 0;

gdjs.Pentagonal_32PyramidCode.eventsList0(runtimeScene);
gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects1.length = 0;
gdjs.Pentagonal_32PyramidCode.GDPentagonprismObjects2.length = 0;
gdjs.Pentagonal_32PyramidCode.GDSideLengthObjects1.length = 0;
gdjs.Pentagonal_32PyramidCode.GDSideLengthObjects2.length = 0;
gdjs.Pentagonal_32PyramidCode.GDLengthObjects1.length = 0;
gdjs.Pentagonal_32PyramidCode.GDLengthObjects2.length = 0;
gdjs.Pentagonal_32PyramidCode.GDAnswerObjects1.length = 0;
gdjs.Pentagonal_32PyramidCode.GDAnswerObjects2.length = 0;
gdjs.Pentagonal_32PyramidCode.GDunitObjects1.length = 0;
gdjs.Pentagonal_32PyramidCode.GDunitObjects2.length = 0;
gdjs.Pentagonal_32PyramidCode.GDNew3DModelObjects1.length = 0;
gdjs.Pentagonal_32PyramidCode.GDNew3DModelObjects2.length = 0;
gdjs.Pentagonal_32PyramidCode.GDBackNewButtonObjects1.length = 0;
gdjs.Pentagonal_32PyramidCode.GDBackNewButtonObjects2.length = 0;
gdjs.Pentagonal_32PyramidCode.GDControlsObjects1.length = 0;
gdjs.Pentagonal_32PyramidCode.GDControlsObjects2.length = 0;
gdjs.Pentagonal_32PyramidCode.GDAnswerButtonObjects1.length = 0;
gdjs.Pentagonal_32PyramidCode.GDAnswerButtonObjects2.length = 0;


return;

}

gdjs['Pentagonal_32PyramidCode'] = gdjs.Pentagonal_32PyramidCode;
