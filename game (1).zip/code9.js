gdjs.OctahedronCode = {};
gdjs.OctahedronCode.localVariables = [];
gdjs.OctahedronCode.GDAnswerButtonObjects1_2final = [];

gdjs.OctahedronCode.GDOctahedronObjects1= [];
gdjs.OctahedronCode.GDOctahedronObjects2= [];
gdjs.OctahedronCode.GDEdgeObjects1= [];
gdjs.OctahedronCode.GDEdgeObjects2= [];
gdjs.OctahedronCode.GDAnswerObjects1= [];
gdjs.OctahedronCode.GDAnswerObjects2= [];
gdjs.OctahedronCode.GDunitObjects1= [];
gdjs.OctahedronCode.GDunitObjects2= [];
gdjs.OctahedronCode.GDBackNewButtonObjects1= [];
gdjs.OctahedronCode.GDBackNewButtonObjects2= [];
gdjs.OctahedronCode.GDControlsObjects1= [];
gdjs.OctahedronCode.GDControlsObjects2= [];
gdjs.OctahedronCode.GDAnswerButtonObjects1= [];
gdjs.OctahedronCode.GDAnswerButtonObjects2= [];


gdjs.OctahedronCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Edge"), gdjs.OctahedronCode.GDEdgeObjects1);
gdjs.OctahedronCode.GDAnswerButtonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
{isConditionTrue_1 = ((gdjs.evtTools.common.toNumber(((( gdjs.OctahedronCode.GDEdgeObjects1.length === 0 ) ? "" :gdjs.OctahedronCode.GDEdgeObjects1[0].getBehavior("Text").getText())))) > 0);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.OctahedronCode.GDAnswerButtonObjects1_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
isConditionTrue_2 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("AnswerButton"), gdjs.OctahedronCode.GDAnswerButtonObjects2);
for (var i = 0, k = 0, l = gdjs.OctahedronCode.GDAnswerButtonObjects2.length;i<l;++i) {
    if ( gdjs.OctahedronCode.GDAnswerButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_2 = true;
        gdjs.OctahedronCode.GDAnswerButtonObjects2[k] = gdjs.OctahedronCode.GDAnswerButtonObjects2[i];
        ++k;
    }
}
gdjs.OctahedronCode.GDAnswerButtonObjects2.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.OctahedronCode.GDAnswerButtonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.OctahedronCode.GDAnswerButtonObjects1_2final.indexOf(gdjs.OctahedronCode.GDAnswerButtonObjects2[j]) === -1 )
            gdjs.OctahedronCode.GDAnswerButtonObjects1_2final.push(gdjs.OctahedronCode.GDAnswerButtonObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.OctahedronCode.GDAnswerButtonObjects1_2final, gdjs.OctahedronCode.GDAnswerButtonObjects1);
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Answer"), gdjs.OctahedronCode.GDAnswerObjects1);
/* Reuse gdjs.OctahedronCode.GDEdgeObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Octahedron"), gdjs.OctahedronCode.GDOctahedronObjects1);
gdjs.copyArray(runtimeScene.getObjects("unit"), gdjs.OctahedronCode.GDunitObjects1);
{for(var i = 0, len = gdjs.OctahedronCode.GDAnswerObjects1.length ;i < len;++i) {
    gdjs.OctahedronCode.GDAnswerObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.common.roundTo(gdjs.evtTools.common.toNumber((( gdjs.OctahedronCode.GDEdgeObjects1.length === 0 ) ? "" :gdjs.OctahedronCode.GDEdgeObjects1[0].getBehavior("Text").getText())) * gdjs.evtTools.common.toNumber((( gdjs.OctahedronCode.GDEdgeObjects1.length === 0 ) ? "" :gdjs.OctahedronCode.GDEdgeObjects1[0].getBehavior("Text").getText())) * gdjs.evtTools.common.toNumber((( gdjs.OctahedronCode.GDEdgeObjects1.length === 0 ) ? "" :gdjs.OctahedronCode.GDEdgeObjects1[0].getBehavior("Text").getText())) * Math.sqrt(2) / 3, 3)) + (( gdjs.OctahedronCode.GDunitObjects1.length === 0 ) ? "" :gdjs.OctahedronCode.GDunitObjects1[0].getBehavior("Text").getText()) + ((gdjs.OctahedronCode.GDunitObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.OctahedronCode.GDunitObjects1[0].getVariables()).getFromIndex(0).getAsString());
}
}{for(var i = 0, len = gdjs.OctahedronCode.GDOctahedronObjects1.length ;i < len;++i) {
    gdjs.OctahedronCode.GDOctahedronObjects1[i].getBehavior("Resizable").setSize(gdjs.evtTools.common.toNumber(((( gdjs.OctahedronCode.GDEdgeObjects1.length === 0 ) ? "" :gdjs.OctahedronCode.GDEdgeObjects1[0].getBehavior("Text").getText()))) * 10, gdjs.evtTools.common.toNumber(((( gdjs.OctahedronCode.GDEdgeObjects1.length === 0 ) ? "" :gdjs.OctahedronCode.GDEdgeObjects1[0].getBehavior("Text").getText()))) * 10);
}
}{for(var i = 0, len = gdjs.OctahedronCode.GDOctahedronObjects1.length ;i < len;++i) {
    gdjs.OctahedronCode.GDOctahedronObjects1[i].getBehavior("Object3D").setDepth(gdjs.evtTools.common.toNumber((( gdjs.OctahedronCode.GDEdgeObjects1.length === 0 ) ? "" :gdjs.OctahedronCode.GDEdgeObjects1[0].getBehavior("Text").getText())) * 10);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Octahedron"), gdjs.OctahedronCode.GDOctahedronObjects1);
{for(var i = 0, len = gdjs.OctahedronCode.GDOctahedronObjects1.length ;i < len;++i) {
    gdjs.OctahedronCode.GDOctahedronObjects1[i].getBehavior("Object3D").turnAroundX(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Octahedron"), gdjs.OctahedronCode.GDOctahedronObjects1);
{for(var i = 0, len = gdjs.OctahedronCode.GDOctahedronObjects1.length ;i < len;++i) {
    gdjs.OctahedronCode.GDOctahedronObjects1[i].getBehavior("Object3D").turnAroundY(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Octahedron"), gdjs.OctahedronCode.GDOctahedronObjects1);
{for(var i = 0, len = gdjs.OctahedronCode.GDOctahedronObjects1.length ;i < len;++i) {
    gdjs.OctahedronCode.GDOctahedronObjects1[i].getBehavior("Object3D").turnAroundY(-(3));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Octahedron"), gdjs.OctahedronCode.GDOctahedronObjects1);
{for(var i = 0, len = gdjs.OctahedronCode.GDOctahedronObjects1.length ;i < len;++i) {
    gdjs.OctahedronCode.GDOctahedronObjects1[i].getBehavior("Object3D").turnAroundX(-(3));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Dash");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Octahedron"), gdjs.OctahedronCode.GDOctahedronObjects1);
{for(var i = 0, len = gdjs.OctahedronCode.GDOctahedronObjects1.length ;i < len;++i) {
    gdjs.OctahedronCode.GDOctahedronObjects1[i].getBehavior("Scale").setScaleX(gdjs.OctahedronCode.GDOctahedronObjects1[i].getBehavior("Scale").getScaleX() / (1.009));
}
}{for(var i = 0, len = gdjs.OctahedronCode.GDOctahedronObjects1.length ;i < len;++i) {
    gdjs.OctahedronCode.GDOctahedronObjects1[i].getBehavior("Scale").setScaleY(gdjs.OctahedronCode.GDOctahedronObjects1[i].getBehavior("Scale").getScaleY() / (1.009));
}
}{for(var i = 0, len = gdjs.OctahedronCode.GDOctahedronObjects1.length ;i < len;++i) {
    gdjs.OctahedronCode.GDOctahedronObjects1[i].getBehavior("Object3D").setScaleZ(gdjs.OctahedronCode.GDOctahedronObjects1[i].getBehavior("Object3D").getScaleZ() / (1.009));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Equal");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Octahedron"), gdjs.OctahedronCode.GDOctahedronObjects1);
{for(var i = 0, len = gdjs.OctahedronCode.GDOctahedronObjects1.length ;i < len;++i) {
    gdjs.OctahedronCode.GDOctahedronObjects1[i].getBehavior("Scale").setScaleX(gdjs.OctahedronCode.GDOctahedronObjects1[i].getBehavior("Scale").getScaleX() * (1.009));
}
}{for(var i = 0, len = gdjs.OctahedronCode.GDOctahedronObjects1.length ;i < len;++i) {
    gdjs.OctahedronCode.GDOctahedronObjects1[i].getBehavior("Object3D").setScaleZ(gdjs.OctahedronCode.GDOctahedronObjects1[i].getBehavior("Object3D").getScaleZ() * (1.009));
}
}{for(var i = 0, len = gdjs.OctahedronCode.GDOctahedronObjects1.length ;i < len;++i) {
    gdjs.OctahedronCode.GDOctahedronObjects1[i].getBehavior("Scale").setScaleY(gdjs.OctahedronCode.GDOctahedronObjects1[i].getBehavior("Scale").getScaleY() * (1.009));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LShift");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Octahedron"), gdjs.OctahedronCode.GDOctahedronObjects1);
{for(var i = 0, len = gdjs.OctahedronCode.GDOctahedronObjects1.length ;i < len;++i) {
    gdjs.OctahedronCode.GDOctahedronObjects1[i].getBehavior("Object3D").turnAroundZ(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LControl");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Octahedron"), gdjs.OctahedronCode.GDOctahedronObjects1);
{for(var i = 0, len = gdjs.OctahedronCode.GDOctahedronObjects1.length ;i < len;++i) {
    gdjs.OctahedronCode.GDOctahedronObjects1[i].getBehavior("Object3D").turnAroundZ(-(3));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BackNewButton"), gdjs.OctahedronCode.GDBackNewButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.OctahedronCode.GDBackNewButtonObjects1.length;i<l;++i) {
    if ( gdjs.OctahedronCode.GDBackNewButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.OctahedronCode.GDBackNewButtonObjects1[k] = gdjs.OctahedronCode.GDBackNewButtonObjects1[i];
        ++k;
    }
}
gdjs.OctahedronCode.GDBackNewButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
if (isConditionTrue_0) {
}

}


};

gdjs.OctahedronCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.OctahedronCode.GDOctahedronObjects1.length = 0;
gdjs.OctahedronCode.GDOctahedronObjects2.length = 0;
gdjs.OctahedronCode.GDEdgeObjects1.length = 0;
gdjs.OctahedronCode.GDEdgeObjects2.length = 0;
gdjs.OctahedronCode.GDAnswerObjects1.length = 0;
gdjs.OctahedronCode.GDAnswerObjects2.length = 0;
gdjs.OctahedronCode.GDunitObjects1.length = 0;
gdjs.OctahedronCode.GDunitObjects2.length = 0;
gdjs.OctahedronCode.GDBackNewButtonObjects1.length = 0;
gdjs.OctahedronCode.GDBackNewButtonObjects2.length = 0;
gdjs.OctahedronCode.GDControlsObjects1.length = 0;
gdjs.OctahedronCode.GDControlsObjects2.length = 0;
gdjs.OctahedronCode.GDAnswerButtonObjects1.length = 0;
gdjs.OctahedronCode.GDAnswerButtonObjects2.length = 0;

gdjs.OctahedronCode.eventsList0(runtimeScene);
gdjs.OctahedronCode.GDOctahedronObjects1.length = 0;
gdjs.OctahedronCode.GDOctahedronObjects2.length = 0;
gdjs.OctahedronCode.GDEdgeObjects1.length = 0;
gdjs.OctahedronCode.GDEdgeObjects2.length = 0;
gdjs.OctahedronCode.GDAnswerObjects1.length = 0;
gdjs.OctahedronCode.GDAnswerObjects2.length = 0;
gdjs.OctahedronCode.GDunitObjects1.length = 0;
gdjs.OctahedronCode.GDunitObjects2.length = 0;
gdjs.OctahedronCode.GDBackNewButtonObjects1.length = 0;
gdjs.OctahedronCode.GDBackNewButtonObjects2.length = 0;
gdjs.OctahedronCode.GDControlsObjects1.length = 0;
gdjs.OctahedronCode.GDControlsObjects2.length = 0;
gdjs.OctahedronCode.GDAnswerButtonObjects1.length = 0;
gdjs.OctahedronCode.GDAnswerButtonObjects2.length = 0;


return;

}

gdjs['OctahedronCode'] = gdjs.OctahedronCode;
