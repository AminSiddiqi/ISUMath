gdjs.SphereCode = {};
gdjs.SphereCode.localVariables = [];
gdjs.SphereCode.GDAnswerButtonObjects1_1final = [];

gdjs.SphereCode.GDSphereObjects1= [];
gdjs.SphereCode.GDSphereObjects2= [];
gdjs.SphereCode.GDRadiusObjects1= [];
gdjs.SphereCode.GDRadiusObjects2= [];
gdjs.SphereCode.GDNewTextObjects1= [];
gdjs.SphereCode.GDNewTextObjects2= [];
gdjs.SphereCode.GDBackNewButtonObjects1= [];
gdjs.SphereCode.GDBackNewButtonObjects2= [];
gdjs.SphereCode.GDControlsObjects1= [];
gdjs.SphereCode.GDControlsObjects2= [];
gdjs.SphereCode.GDAnswerButtonObjects1= [];
gdjs.SphereCode.GDAnswerButtonObjects2= [];


gdjs.SphereCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Dash");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sphere"), gdjs.SphereCode.GDSphereObjects1);
{for(var i = 0, len = gdjs.SphereCode.GDSphereObjects1.length ;i < len;++i) {
    gdjs.SphereCode.GDSphereObjects1[i].getBehavior("Scale").setScaleX(gdjs.SphereCode.GDSphereObjects1[i].getBehavior("Scale").getScaleX() / (1.009));
}
}{for(var i = 0, len = gdjs.SphereCode.GDSphereObjects1.length ;i < len;++i) {
    gdjs.SphereCode.GDSphereObjects1[i].getBehavior("Scale").setScaleY(gdjs.SphereCode.GDSphereObjects1[i].getBehavior("Scale").getScaleY() / (1.009));
}
}{for(var i = 0, len = gdjs.SphereCode.GDSphereObjects1.length ;i < len;++i) {
    gdjs.SphereCode.GDSphereObjects1[i].getBehavior("Object3D").setScaleZ(gdjs.SphereCode.GDSphereObjects1[i].getBehavior("Object3D").getScaleZ() / (1.009));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Equal");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sphere"), gdjs.SphereCode.GDSphereObjects1);
{for(var i = 0, len = gdjs.SphereCode.GDSphereObjects1.length ;i < len;++i) {
    gdjs.SphereCode.GDSphereObjects1[i].getBehavior("Scale").setScaleY(gdjs.SphereCode.GDSphereObjects1[i].getBehavior("Scale").getScaleY() * (1.009));
}
}{for(var i = 0, len = gdjs.SphereCode.GDSphereObjects1.length ;i < len;++i) {
    gdjs.SphereCode.GDSphereObjects1[i].getBehavior("Scale").setScaleX(gdjs.SphereCode.GDSphereObjects1[i].getBehavior("Scale").getScaleX() * (1.009));
}
}{for(var i = 0, len = gdjs.SphereCode.GDSphereObjects1.length ;i < len;++i) {
    gdjs.SphereCode.GDSphereObjects1[i].getBehavior("Object3D").setScaleZ(gdjs.SphereCode.GDSphereObjects1[i].getBehavior("Object3D").getScaleZ() * (1.009));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Radius"), gdjs.SphereCode.GDRadiusObjects1);
gdjs.SphereCode.GDAnswerButtonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.common.toNumber((( gdjs.SphereCode.GDRadiusObjects1.length === 0 ) ? "" :gdjs.SphereCode.GDRadiusObjects1[0].getBehavior("Text").getText())) > 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.SphereCode.GDAnswerButtonObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("AnswerButton"), gdjs.SphereCode.GDAnswerButtonObjects2);
for (var i = 0, k = 0, l = gdjs.SphereCode.GDAnswerButtonObjects2.length;i<l;++i) {
    if ( gdjs.SphereCode.GDAnswerButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SphereCode.GDAnswerButtonObjects2[k] = gdjs.SphereCode.GDAnswerButtonObjects2[i];
        ++k;
    }
}
gdjs.SphereCode.GDAnswerButtonObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SphereCode.GDAnswerButtonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.SphereCode.GDAnswerButtonObjects1_1final.indexOf(gdjs.SphereCode.GDAnswerButtonObjects2[j]) === -1 )
            gdjs.SphereCode.GDAnswerButtonObjects1_1final.push(gdjs.SphereCode.GDAnswerButtonObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.SphereCode.GDAnswerButtonObjects1_1final, gdjs.SphereCode.GDAnswerButtonObjects1);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.SphereCode.GDNewTextObjects1);
/* Reuse gdjs.SphereCode.GDRadiusObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Sphere"), gdjs.SphereCode.GDSphereObjects1);
{for(var i = 0, len = gdjs.SphereCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.SphereCode.GDNewTextObjects1[i].getBehavior("Text").setText((gdjs.evtTools.common.toString(gdjs.evtTools.common.roundTo(gdjs.evtTools.common.toNumber((( gdjs.SphereCode.GDRadiusObjects1.length === 0 ) ? "" :gdjs.SphereCode.GDRadiusObjects1[0].getBehavior("Text").getText())) * (gdjs.evtTools.common.toNumber((( gdjs.SphereCode.GDRadiusObjects1.length === 0 ) ? "" :gdjs.SphereCode.GDRadiusObjects1[0].getBehavior("Text").getText()))) * (gdjs.evtTools.common.toNumber((( gdjs.SphereCode.GDRadiusObjects1.length === 0 ) ? "" :gdjs.SphereCode.GDRadiusObjects1[0].getBehavior("Text").getText())) * 3.14159 * (4 / 3)), 3))));
}
}{for(var i = 0, len = gdjs.SphereCode.GDSphereObjects1.length ;i < len;++i) {
    gdjs.SphereCode.GDSphereObjects1[i].getBehavior("Object3D").setScaleZ(gdjs.evtTools.common.toNumber((( gdjs.SphereCode.GDRadiusObjects1.length === 0 ) ? "" :gdjs.SphereCode.GDRadiusObjects1[0].getBehavior("Text").getText())) * 2);
}
}{for(var i = 0, len = gdjs.SphereCode.GDSphereObjects1.length ;i < len;++i) {
    gdjs.SphereCode.GDSphereObjects1[i].getBehavior("Scale").setScaleX(gdjs.evtTools.common.toNumber((( gdjs.SphereCode.GDRadiusObjects1.length === 0 ) ? "" :gdjs.SphereCode.GDRadiusObjects1[0].getBehavior("Text").getText())) * 2);
}
}{for(var i = 0, len = gdjs.SphereCode.GDSphereObjects1.length ;i < len;++i) {
    gdjs.SphereCode.GDSphereObjects1[i].getBehavior("Scale").setScaleY(gdjs.evtTools.common.toNumber((( gdjs.SphereCode.GDRadiusObjects1.length === 0 ) ? "" :gdjs.SphereCode.GDRadiusObjects1[0].getBehavior("Text").getText())) * 2);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BackNewButton"), gdjs.SphereCode.GDBackNewButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SphereCode.GDBackNewButtonObjects1.length;i<l;++i) {
    if ( gdjs.SphereCode.GDBackNewButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.SphereCode.GDBackNewButtonObjects1[k] = gdjs.SphereCode.GDBackNewButtonObjects1[i];
        ++k;
    }
}
gdjs.SphereCode.GDBackNewButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


};

gdjs.SphereCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.SphereCode.GDSphereObjects1.length = 0;
gdjs.SphereCode.GDSphereObjects2.length = 0;
gdjs.SphereCode.GDRadiusObjects1.length = 0;
gdjs.SphereCode.GDRadiusObjects2.length = 0;
gdjs.SphereCode.GDNewTextObjects1.length = 0;
gdjs.SphereCode.GDNewTextObjects2.length = 0;
gdjs.SphereCode.GDBackNewButtonObjects1.length = 0;
gdjs.SphereCode.GDBackNewButtonObjects2.length = 0;
gdjs.SphereCode.GDControlsObjects1.length = 0;
gdjs.SphereCode.GDControlsObjects2.length = 0;
gdjs.SphereCode.GDAnswerButtonObjects1.length = 0;
gdjs.SphereCode.GDAnswerButtonObjects2.length = 0;

gdjs.SphereCode.eventsList0(runtimeScene);
gdjs.SphereCode.GDSphereObjects1.length = 0;
gdjs.SphereCode.GDSphereObjects2.length = 0;
gdjs.SphereCode.GDRadiusObjects1.length = 0;
gdjs.SphereCode.GDRadiusObjects2.length = 0;
gdjs.SphereCode.GDNewTextObjects1.length = 0;
gdjs.SphereCode.GDNewTextObjects2.length = 0;
gdjs.SphereCode.GDBackNewButtonObjects1.length = 0;
gdjs.SphereCode.GDBackNewButtonObjects2.length = 0;
gdjs.SphereCode.GDControlsObjects1.length = 0;
gdjs.SphereCode.GDControlsObjects2.length = 0;
gdjs.SphereCode.GDAnswerButtonObjects1.length = 0;
gdjs.SphereCode.GDAnswerButtonObjects2.length = 0;


return;

}

gdjs['SphereCode'] = gdjs.SphereCode;
