gdjs.PyramidsMenuCode = {};
gdjs.PyramidsMenuCode.localVariables = [];
gdjs.PyramidsMenuCode.GDIntroObjects1= [];
gdjs.PyramidsMenuCode.GDIntroObjects2= [];
gdjs.PyramidsMenuCode.GDDirectToTriangularPyramidObjects1= [];
gdjs.PyramidsMenuCode.GDDirectToTriangularPyramidObjects2= [];
gdjs.PyramidsMenuCode.GDDirectToSquarePyramidObjects1= [];
gdjs.PyramidsMenuCode.GDDirectToSquarePyramidObjects2= [];
gdjs.PyramidsMenuCode.GDDirectToConeObjects1= [];
gdjs.PyramidsMenuCode.GDDirectToConeObjects2= [];
gdjs.PyramidsMenuCode.GDDirectToPentagonalPyramidObjects1= [];
gdjs.PyramidsMenuCode.GDDirectToPentagonalPyramidObjects2= [];
gdjs.PyramidsMenuCode.GDDirectToHexagonalPyramidObjects1= [];
gdjs.PyramidsMenuCode.GDDirectToHexagonalPyramidObjects2= [];
gdjs.PyramidsMenuCode.GDBackNewButtonObjects1= [];
gdjs.PyramidsMenuCode.GDBackNewButtonObjects2= [];
gdjs.PyramidsMenuCode.GDControlsObjects1= [];
gdjs.PyramidsMenuCode.GDControlsObjects2= [];
gdjs.PyramidsMenuCode.GDAnswerButtonObjects1= [];
gdjs.PyramidsMenuCode.GDAnswerButtonObjects2= [];


gdjs.PyramidsMenuCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DirectToTriangularPyramid"), gdjs.PyramidsMenuCode.GDDirectToTriangularPyramidObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PyramidsMenuCode.GDDirectToTriangularPyramidObjects1.length;i<l;++i) {
    if ( gdjs.PyramidsMenuCode.GDDirectToTriangularPyramidObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PyramidsMenuCode.GDDirectToTriangularPyramidObjects1[k] = gdjs.PyramidsMenuCode.GDDirectToTriangularPyramidObjects1[i];
        ++k;
    }
}
gdjs.PyramidsMenuCode.GDDirectToTriangularPyramidObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Triangle Pyramid", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DirectToSquarePyramid"), gdjs.PyramidsMenuCode.GDDirectToSquarePyramidObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PyramidsMenuCode.GDDirectToSquarePyramidObjects1.length;i<l;++i) {
    if ( gdjs.PyramidsMenuCode.GDDirectToSquarePyramidObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PyramidsMenuCode.GDDirectToSquarePyramidObjects1[k] = gdjs.PyramidsMenuCode.GDDirectToSquarePyramidObjects1[i];
        ++k;
    }
}
gdjs.PyramidsMenuCode.GDDirectToSquarePyramidObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Square Pyramid", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DirectToCone"), gdjs.PyramidsMenuCode.GDDirectToConeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PyramidsMenuCode.GDDirectToConeObjects1.length;i<l;++i) {
    if ( gdjs.PyramidsMenuCode.GDDirectToConeObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PyramidsMenuCode.GDDirectToConeObjects1[k] = gdjs.PyramidsMenuCode.GDDirectToConeObjects1[i];
        ++k;
    }
}
gdjs.PyramidsMenuCode.GDDirectToConeObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Cone", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BackNewButton"), gdjs.PyramidsMenuCode.GDBackNewButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PyramidsMenuCode.GDBackNewButtonObjects1.length;i<l;++i) {
    if ( gdjs.PyramidsMenuCode.GDBackNewButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PyramidsMenuCode.GDBackNewButtonObjects1[k] = gdjs.PyramidsMenuCode.GDBackNewButtonObjects1[i];
        ++k;
    }
}
gdjs.PyramidsMenuCode.GDBackNewButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DirectToPentagonalPyramid"), gdjs.PyramidsMenuCode.GDDirectToPentagonalPyramidObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PyramidsMenuCode.GDDirectToPentagonalPyramidObjects1.length;i<l;++i) {
    if ( gdjs.PyramidsMenuCode.GDDirectToPentagonalPyramidObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PyramidsMenuCode.GDDirectToPentagonalPyramidObjects1[k] = gdjs.PyramidsMenuCode.GDDirectToPentagonalPyramidObjects1[i];
        ++k;
    }
}
gdjs.PyramidsMenuCode.GDDirectToPentagonalPyramidObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Pentagonal Pyramid", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DirectToHexagonalPyramid"), gdjs.PyramidsMenuCode.GDDirectToHexagonalPyramidObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PyramidsMenuCode.GDDirectToHexagonalPyramidObjects1.length;i<l;++i) {
    if ( gdjs.PyramidsMenuCode.GDDirectToHexagonalPyramidObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PyramidsMenuCode.GDDirectToHexagonalPyramidObjects1[k] = gdjs.PyramidsMenuCode.GDDirectToHexagonalPyramidObjects1[i];
        ++k;
    }
}
gdjs.PyramidsMenuCode.GDDirectToHexagonalPyramidObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Hexagonal Pyramid", false);
}}

}


};

gdjs.PyramidsMenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.PyramidsMenuCode.GDIntroObjects1.length = 0;
gdjs.PyramidsMenuCode.GDIntroObjects2.length = 0;
gdjs.PyramidsMenuCode.GDDirectToTriangularPyramidObjects1.length = 0;
gdjs.PyramidsMenuCode.GDDirectToTriangularPyramidObjects2.length = 0;
gdjs.PyramidsMenuCode.GDDirectToSquarePyramidObjects1.length = 0;
gdjs.PyramidsMenuCode.GDDirectToSquarePyramidObjects2.length = 0;
gdjs.PyramidsMenuCode.GDDirectToConeObjects1.length = 0;
gdjs.PyramidsMenuCode.GDDirectToConeObjects2.length = 0;
gdjs.PyramidsMenuCode.GDDirectToPentagonalPyramidObjects1.length = 0;
gdjs.PyramidsMenuCode.GDDirectToPentagonalPyramidObjects2.length = 0;
gdjs.PyramidsMenuCode.GDDirectToHexagonalPyramidObjects1.length = 0;
gdjs.PyramidsMenuCode.GDDirectToHexagonalPyramidObjects2.length = 0;
gdjs.PyramidsMenuCode.GDBackNewButtonObjects1.length = 0;
gdjs.PyramidsMenuCode.GDBackNewButtonObjects2.length = 0;
gdjs.PyramidsMenuCode.GDControlsObjects1.length = 0;
gdjs.PyramidsMenuCode.GDControlsObjects2.length = 0;
gdjs.PyramidsMenuCode.GDAnswerButtonObjects1.length = 0;
gdjs.PyramidsMenuCode.GDAnswerButtonObjects2.length = 0;

gdjs.PyramidsMenuCode.eventsList0(runtimeScene);
gdjs.PyramidsMenuCode.GDIntroObjects1.length = 0;
gdjs.PyramidsMenuCode.GDIntroObjects2.length = 0;
gdjs.PyramidsMenuCode.GDDirectToTriangularPyramidObjects1.length = 0;
gdjs.PyramidsMenuCode.GDDirectToTriangularPyramidObjects2.length = 0;
gdjs.PyramidsMenuCode.GDDirectToSquarePyramidObjects1.length = 0;
gdjs.PyramidsMenuCode.GDDirectToSquarePyramidObjects2.length = 0;
gdjs.PyramidsMenuCode.GDDirectToConeObjects1.length = 0;
gdjs.PyramidsMenuCode.GDDirectToConeObjects2.length = 0;
gdjs.PyramidsMenuCode.GDDirectToPentagonalPyramidObjects1.length = 0;
gdjs.PyramidsMenuCode.GDDirectToPentagonalPyramidObjects2.length = 0;
gdjs.PyramidsMenuCode.GDDirectToHexagonalPyramidObjects1.length = 0;
gdjs.PyramidsMenuCode.GDDirectToHexagonalPyramidObjects2.length = 0;
gdjs.PyramidsMenuCode.GDBackNewButtonObjects1.length = 0;
gdjs.PyramidsMenuCode.GDBackNewButtonObjects2.length = 0;
gdjs.PyramidsMenuCode.GDControlsObjects1.length = 0;
gdjs.PyramidsMenuCode.GDControlsObjects2.length = 0;
gdjs.PyramidsMenuCode.GDAnswerButtonObjects1.length = 0;
gdjs.PyramidsMenuCode.GDAnswerButtonObjects2.length = 0;


return;

}

gdjs['PyramidsMenuCode'] = gdjs.PyramidsMenuCode;
