gdjs.Hexagonal_32PyramidCode = {};
gdjs.Hexagonal_32PyramidCode.localVariables = [];
gdjs.Hexagonal_32PyramidCode.GDAnswerButtonObjects1_2final = [];

gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1= [];
gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects2= [];
gdjs.Hexagonal_32PyramidCode.GDSideLengthObjects1= [];
gdjs.Hexagonal_32PyramidCode.GDSideLengthObjects2= [];
gdjs.Hexagonal_32PyramidCode.GDLengthObjects1= [];
gdjs.Hexagonal_32PyramidCode.GDLengthObjects2= [];
gdjs.Hexagonal_32PyramidCode.GDAnswerObjects1= [];
gdjs.Hexagonal_32PyramidCode.GDAnswerObjects2= [];
gdjs.Hexagonal_32PyramidCode.GDunitObjects1= [];
gdjs.Hexagonal_32PyramidCode.GDunitObjects2= [];
gdjs.Hexagonal_32PyramidCode.GDNew3DModelObjects1= [];
gdjs.Hexagonal_32PyramidCode.GDNew3DModelObjects2= [];
gdjs.Hexagonal_32PyramidCode.GDBackNewButtonObjects1= [];
gdjs.Hexagonal_32PyramidCode.GDBackNewButtonObjects2= [];
gdjs.Hexagonal_32PyramidCode.GDControlsObjects1= [];
gdjs.Hexagonal_32PyramidCode.GDControlsObjects2= [];
gdjs.Hexagonal_32PyramidCode.GDAnswerButtonObjects1= [];
gdjs.Hexagonal_32PyramidCode.GDAnswerButtonObjects2= [];


gdjs.Hexagonal_32PyramidCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Length"), gdjs.Hexagonal_32PyramidCode.GDLengthObjects1);
gdjs.copyArray(runtimeScene.getObjects("SideLength"), gdjs.Hexagonal_32PyramidCode.GDSideLengthObjects1);
gdjs.Hexagonal_32PyramidCode.GDAnswerButtonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
{isConditionTrue_1 = ((gdjs.evtTools.common.toNumber(((( gdjs.Hexagonal_32PyramidCode.GDSideLengthObjects1.length === 0 ) ? "" :gdjs.Hexagonal_32PyramidCode.GDSideLengthObjects1[0].getBehavior("Text").getText())))) > 0);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = ((gdjs.evtTools.common.toNumber(((( gdjs.Hexagonal_32PyramidCode.GDLengthObjects1.length === 0 ) ? "" :gdjs.Hexagonal_32PyramidCode.GDLengthObjects1[0].getBehavior("Text").getText())))) > 0);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.Hexagonal_32PyramidCode.GDAnswerButtonObjects1_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
isConditionTrue_2 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("AnswerButton"), gdjs.Hexagonal_32PyramidCode.GDAnswerButtonObjects2);
for (var i = 0, k = 0, l = gdjs.Hexagonal_32PyramidCode.GDAnswerButtonObjects2.length;i<l;++i) {
    if ( gdjs.Hexagonal_32PyramidCode.GDAnswerButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_2 = true;
        gdjs.Hexagonal_32PyramidCode.GDAnswerButtonObjects2[k] = gdjs.Hexagonal_32PyramidCode.GDAnswerButtonObjects2[i];
        ++k;
    }
}
gdjs.Hexagonal_32PyramidCode.GDAnswerButtonObjects2.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Hexagonal_32PyramidCode.GDAnswerButtonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Hexagonal_32PyramidCode.GDAnswerButtonObjects1_2final.indexOf(gdjs.Hexagonal_32PyramidCode.GDAnswerButtonObjects2[j]) === -1 )
            gdjs.Hexagonal_32PyramidCode.GDAnswerButtonObjects1_2final.push(gdjs.Hexagonal_32PyramidCode.GDAnswerButtonObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Hexagonal_32PyramidCode.GDAnswerButtonObjects1_2final, gdjs.Hexagonal_32PyramidCode.GDAnswerButtonObjects1);
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Answer"), gdjs.Hexagonal_32PyramidCode.GDAnswerObjects1);
/* Reuse gdjs.Hexagonal_32PyramidCode.GDLengthObjects1 */
gdjs.copyArray(runtimeScene.getObjects("PentagonPyramid"), gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1);
/* Reuse gdjs.Hexagonal_32PyramidCode.GDSideLengthObjects1 */
gdjs.copyArray(runtimeScene.getObjects("unit"), gdjs.Hexagonal_32PyramidCode.GDunitObjects1);
{for(var i = 0, len = gdjs.Hexagonal_32PyramidCode.GDAnswerObjects1.length ;i < len;++i) {
    gdjs.Hexagonal_32PyramidCode.GDAnswerObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.common.roundTo(gdjs.evtTools.common.toNumber((( gdjs.Hexagonal_32PyramidCode.GDSideLengthObjects1.length === 0 ) ? "" :gdjs.Hexagonal_32PyramidCode.GDSideLengthObjects1[0].getBehavior("Text").getText())) * gdjs.evtTools.common.toNumber((( gdjs.Hexagonal_32PyramidCode.GDSideLengthObjects1.length === 0 ) ? "" :gdjs.Hexagonal_32PyramidCode.GDSideLengthObjects1[0].getBehavior("Text").getText())) * gdjs.evtTools.common.toNumber((( gdjs.Hexagonal_32PyramidCode.GDLengthObjects1.length === 0 ) ? "" :gdjs.Hexagonal_32PyramidCode.GDLengthObjects1[0].getBehavior("Text").getText())) * ((3 * Math.sqrt(3)) / 2 / 3), 3)) + (( gdjs.Hexagonal_32PyramidCode.GDunitObjects1.length === 0 ) ? "" :gdjs.Hexagonal_32PyramidCode.GDunitObjects1[0].getBehavior("Text").getText()) + ((gdjs.Hexagonal_32PyramidCode.GDunitObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Hexagonal_32PyramidCode.GDunitObjects1[0].getVariables()).getFromIndex(0).getAsString());
}
}{for(var i = 0, len = gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1.length ;i < len;++i) {
    gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1[i].getBehavior("Resizable").setSize(gdjs.evtTools.common.toNumber(((( gdjs.Hexagonal_32PyramidCode.GDSideLengthObjects1.length === 0 ) ? "" :gdjs.Hexagonal_32PyramidCode.GDSideLengthObjects1[0].getBehavior("Text").getText()))) * 10, gdjs.evtTools.common.toNumber(((( gdjs.Hexagonal_32PyramidCode.GDSideLengthObjects1.length === 0 ) ? "" :gdjs.Hexagonal_32PyramidCode.GDSideLengthObjects1[0].getBehavior("Text").getText()))) * 10);
}
}{for(var i = 0, len = gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1.length ;i < len;++i) {
    gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1[i].getBehavior("Object3D").setDepth(gdjs.evtTools.common.toNumber((( gdjs.Hexagonal_32PyramidCode.GDLengthObjects1.length === 0 ) ? "" :gdjs.Hexagonal_32PyramidCode.GDLengthObjects1[0].getBehavior("Text").getText())) * 10);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PentagonPyramid"), gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1);
{for(var i = 0, len = gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1.length ;i < len;++i) {
    gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1[i].getBehavior("Object3D").turnAroundX(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PentagonPyramid"), gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1);
{for(var i = 0, len = gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1.length ;i < len;++i) {
    gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1[i].getBehavior("Object3D").turnAroundY(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PentagonPyramid"), gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1);
{for(var i = 0, len = gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1.length ;i < len;++i) {
    gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1[i].getBehavior("Object3D").turnAroundY(-(3));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PentagonPyramid"), gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1);
{for(var i = 0, len = gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1.length ;i < len;++i) {
    gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1[i].getBehavior("Object3D").turnAroundX(-(3));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Dash");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PentagonPyramid"), gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1);
{for(var i = 0, len = gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1.length ;i < len;++i) {
    gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1[i].getBehavior("Scale").setScaleX(gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1[i].getBehavior("Scale").getScaleX() / (1.009));
}
}{for(var i = 0, len = gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1.length ;i < len;++i) {
    gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1[i].getBehavior("Scale").setScaleY(gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1[i].getBehavior("Scale").getScaleY() / (1.009));
}
}{for(var i = 0, len = gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1.length ;i < len;++i) {
    gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1[i].getBehavior("Object3D").setScaleZ(gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1[i].getBehavior("Object3D").getScaleZ() / (1.009));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Equal");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PentagonPyramid"), gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1);
{for(var i = 0, len = gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1.length ;i < len;++i) {
    gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1[i].getBehavior("Scale").setScaleX(gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1[i].getBehavior("Scale").getScaleX() * (1.009));
}
}{for(var i = 0, len = gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1.length ;i < len;++i) {
    gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1[i].getBehavior("Object3D").setScaleZ(gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1[i].getBehavior("Object3D").getScaleZ() * (1.009));
}
}{for(var i = 0, len = gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1.length ;i < len;++i) {
    gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1[i].getBehavior("Scale").setScaleY(gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1[i].getBehavior("Scale").getScaleY() * (1.009));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LShift");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PentagonPyramid"), gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1);
{for(var i = 0, len = gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1.length ;i < len;++i) {
    gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1[i].getBehavior("Object3D").turnAroundZ(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LControl");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PentagonPyramid"), gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1);
{for(var i = 0, len = gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1.length ;i < len;++i) {
    gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1[i].getBehavior("Object3D").turnAroundZ(-(3));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BackNewButton"), gdjs.Hexagonal_32PyramidCode.GDBackNewButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Hexagonal_32PyramidCode.GDBackNewButtonObjects1.length;i<l;++i) {
    if ( gdjs.Hexagonal_32PyramidCode.GDBackNewButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Hexagonal_32PyramidCode.GDBackNewButtonObjects1[k] = gdjs.Hexagonal_32PyramidCode.GDBackNewButtonObjects1[i];
        ++k;
    }
}
gdjs.Hexagonal_32PyramidCode.GDBackNewButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


};

gdjs.Hexagonal_32PyramidCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1.length = 0;
gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects2.length = 0;
gdjs.Hexagonal_32PyramidCode.GDSideLengthObjects1.length = 0;
gdjs.Hexagonal_32PyramidCode.GDSideLengthObjects2.length = 0;
gdjs.Hexagonal_32PyramidCode.GDLengthObjects1.length = 0;
gdjs.Hexagonal_32PyramidCode.GDLengthObjects2.length = 0;
gdjs.Hexagonal_32PyramidCode.GDAnswerObjects1.length = 0;
gdjs.Hexagonal_32PyramidCode.GDAnswerObjects2.length = 0;
gdjs.Hexagonal_32PyramidCode.GDunitObjects1.length = 0;
gdjs.Hexagonal_32PyramidCode.GDunitObjects2.length = 0;
gdjs.Hexagonal_32PyramidCode.GDNew3DModelObjects1.length = 0;
gdjs.Hexagonal_32PyramidCode.GDNew3DModelObjects2.length = 0;
gdjs.Hexagonal_32PyramidCode.GDBackNewButtonObjects1.length = 0;
gdjs.Hexagonal_32PyramidCode.GDBackNewButtonObjects2.length = 0;
gdjs.Hexagonal_32PyramidCode.GDControlsObjects1.length = 0;
gdjs.Hexagonal_32PyramidCode.GDControlsObjects2.length = 0;
gdjs.Hexagonal_32PyramidCode.GDAnswerButtonObjects1.length = 0;
gdjs.Hexagonal_32PyramidCode.GDAnswerButtonObjects2.length = 0;

gdjs.Hexagonal_32PyramidCode.eventsList0(runtimeScene);
gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects1.length = 0;
gdjs.Hexagonal_32PyramidCode.GDPentagonPyramidObjects2.length = 0;
gdjs.Hexagonal_32PyramidCode.GDSideLengthObjects1.length = 0;
gdjs.Hexagonal_32PyramidCode.GDSideLengthObjects2.length = 0;
gdjs.Hexagonal_32PyramidCode.GDLengthObjects1.length = 0;
gdjs.Hexagonal_32PyramidCode.GDLengthObjects2.length = 0;
gdjs.Hexagonal_32PyramidCode.GDAnswerObjects1.length = 0;
gdjs.Hexagonal_32PyramidCode.GDAnswerObjects2.length = 0;
gdjs.Hexagonal_32PyramidCode.GDunitObjects1.length = 0;
gdjs.Hexagonal_32PyramidCode.GDunitObjects2.length = 0;
gdjs.Hexagonal_32PyramidCode.GDNew3DModelObjects1.length = 0;
gdjs.Hexagonal_32PyramidCode.GDNew3DModelObjects2.length = 0;
gdjs.Hexagonal_32PyramidCode.GDBackNewButtonObjects1.length = 0;
gdjs.Hexagonal_32PyramidCode.GDBackNewButtonObjects2.length = 0;
gdjs.Hexagonal_32PyramidCode.GDControlsObjects1.length = 0;
gdjs.Hexagonal_32PyramidCode.GDControlsObjects2.length = 0;
gdjs.Hexagonal_32PyramidCode.GDAnswerButtonObjects1.length = 0;
gdjs.Hexagonal_32PyramidCode.GDAnswerButtonObjects2.length = 0;


return;

}

gdjs['Hexagonal_32PyramidCode'] = gdjs.Hexagonal_32PyramidCode;
