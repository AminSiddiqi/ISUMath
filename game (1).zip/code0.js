gdjs.MenuCode = {};
gdjs.MenuCode.localVariables = [];
gdjs.MenuCode.GDIntroObjects1= [];
gdjs.MenuCode.GDIntroObjects2= [];
gdjs.MenuCode.GDDirectToPrismsObjects1= [];
gdjs.MenuCode.GDDirectToPrismsObjects2= [];
gdjs.MenuCode.GDDirectToSphereObjects1= [];
gdjs.MenuCode.GDDirectToSphereObjects2= [];
gdjs.MenuCode.GDDirectToPyramidObjects1= [];
gdjs.MenuCode.GDDirectToPyramidObjects2= [];
gdjs.MenuCode.GDDirectToOctahedronObjects1= [];
gdjs.MenuCode.GDDirectToOctahedronObjects2= [];
gdjs.MenuCode.GDBackNewButtonObjects1= [];
gdjs.MenuCode.GDBackNewButtonObjects2= [];
gdjs.MenuCode.GDControlsObjects1= [];
gdjs.MenuCode.GDControlsObjects2= [];
gdjs.MenuCode.GDAnswerButtonObjects1= [];
gdjs.MenuCode.GDAnswerButtonObjects2= [];


gdjs.MenuCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("DirectToPrisms"), gdjs.MenuCode.GDDirectToPrismsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDDirectToPrismsObjects1.length;i<l;++i) {
    if ( gdjs.MenuCode.GDDirectToPrismsObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDDirectToPrismsObjects1[k] = gdjs.MenuCode.GDDirectToPrismsObjects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDDirectToPrismsObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Prism Menu", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DirectToSphere"), gdjs.MenuCode.GDDirectToSphereObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDDirectToSphereObjects1.length;i<l;++i) {
    if ( gdjs.MenuCode.GDDirectToSphereObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDDirectToSphereObjects1[k] = gdjs.MenuCode.GDDirectToSphereObjects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDDirectToSphereObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Sphere", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DirectToPyramid"), gdjs.MenuCode.GDDirectToPyramidObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDDirectToPyramidObjects1.length;i<l;++i) {
    if ( gdjs.MenuCode.GDDirectToPyramidObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDDirectToPyramidObjects1[k] = gdjs.MenuCode.GDDirectToPyramidObjects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDDirectToPyramidObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "PyramidsMenu", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DirectToOctahedron"), gdjs.MenuCode.GDDirectToOctahedronObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDDirectToOctahedronObjects1.length;i<l;++i) {
    if ( gdjs.MenuCode.GDDirectToOctahedronObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDDirectToOctahedronObjects1[k] = gdjs.MenuCode.GDDirectToOctahedronObjects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDDirectToOctahedronObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Octahedron", false);
}}

}


};

gdjs.MenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MenuCode.GDIntroObjects1.length = 0;
gdjs.MenuCode.GDIntroObjects2.length = 0;
gdjs.MenuCode.GDDirectToPrismsObjects1.length = 0;
gdjs.MenuCode.GDDirectToPrismsObjects2.length = 0;
gdjs.MenuCode.GDDirectToSphereObjects1.length = 0;
gdjs.MenuCode.GDDirectToSphereObjects2.length = 0;
gdjs.MenuCode.GDDirectToPyramidObjects1.length = 0;
gdjs.MenuCode.GDDirectToPyramidObjects2.length = 0;
gdjs.MenuCode.GDDirectToOctahedronObjects1.length = 0;
gdjs.MenuCode.GDDirectToOctahedronObjects2.length = 0;
gdjs.MenuCode.GDBackNewButtonObjects1.length = 0;
gdjs.MenuCode.GDBackNewButtonObjects2.length = 0;
gdjs.MenuCode.GDControlsObjects1.length = 0;
gdjs.MenuCode.GDControlsObjects2.length = 0;
gdjs.MenuCode.GDAnswerButtonObjects1.length = 0;
gdjs.MenuCode.GDAnswerButtonObjects2.length = 0;

gdjs.MenuCode.eventsList0(runtimeScene);
gdjs.MenuCode.GDIntroObjects1.length = 0;
gdjs.MenuCode.GDIntroObjects2.length = 0;
gdjs.MenuCode.GDDirectToPrismsObjects1.length = 0;
gdjs.MenuCode.GDDirectToPrismsObjects2.length = 0;
gdjs.MenuCode.GDDirectToSphereObjects1.length = 0;
gdjs.MenuCode.GDDirectToSphereObjects2.length = 0;
gdjs.MenuCode.GDDirectToPyramidObjects1.length = 0;
gdjs.MenuCode.GDDirectToPyramidObjects2.length = 0;
gdjs.MenuCode.GDDirectToOctahedronObjects1.length = 0;
gdjs.MenuCode.GDDirectToOctahedronObjects2.length = 0;
gdjs.MenuCode.GDBackNewButtonObjects1.length = 0;
gdjs.MenuCode.GDBackNewButtonObjects2.length = 0;
gdjs.MenuCode.GDControlsObjects1.length = 0;
gdjs.MenuCode.GDControlsObjects2.length = 0;
gdjs.MenuCode.GDAnswerButtonObjects1.length = 0;
gdjs.MenuCode.GDAnswerButtonObjects2.length = 0;


return;

}

gdjs['MenuCode'] = gdjs.MenuCode;
