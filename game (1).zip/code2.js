gdjs.Square_32PyramidCode = {};
gdjs.Square_32PyramidCode.localVariables = [];
gdjs.Square_32PyramidCode.GDAnswerButtonObjects1_2final = [];

gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1= [];
gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects2= [];
gdjs.Square_32PyramidCode.GDheightObjects1= [];
gdjs.Square_32PyramidCode.GDheightObjects2= [];
gdjs.Square_32PyramidCode.GDWidthObjects1= [];
gdjs.Square_32PyramidCode.GDWidthObjects2= [];
gdjs.Square_32PyramidCode.GDLengthObjects1= [];
gdjs.Square_32PyramidCode.GDLengthObjects2= [];
gdjs.Square_32PyramidCode.GDAnswerObjects1= [];
gdjs.Square_32PyramidCode.GDAnswerObjects2= [];
gdjs.Square_32PyramidCode.GDunitObjects1= [];
gdjs.Square_32PyramidCode.GDunitObjects2= [];
gdjs.Square_32PyramidCode.GDBackNewButtonObjects1= [];
gdjs.Square_32PyramidCode.GDBackNewButtonObjects2= [];
gdjs.Square_32PyramidCode.GDControlsObjects1= [];
gdjs.Square_32PyramidCode.GDControlsObjects2= [];
gdjs.Square_32PyramidCode.GDAnswerButtonObjects1= [];
gdjs.Square_32PyramidCode.GDAnswerButtonObjects2= [];


gdjs.Square_32PyramidCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Length"), gdjs.Square_32PyramidCode.GDLengthObjects1);
gdjs.copyArray(runtimeScene.getObjects("Width"), gdjs.Square_32PyramidCode.GDWidthObjects1);
gdjs.copyArray(runtimeScene.getObjects("height"), gdjs.Square_32PyramidCode.GDheightObjects1);
gdjs.Square_32PyramidCode.GDAnswerButtonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
{isConditionTrue_1 = ((gdjs.evtTools.common.toNumber(((( gdjs.Square_32PyramidCode.GDheightObjects1.length === 0 ) ? "" :gdjs.Square_32PyramidCode.GDheightObjects1[0].getBehavior("Text").getText())))) > 0);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = ((gdjs.evtTools.common.toNumber(((( gdjs.Square_32PyramidCode.GDWidthObjects1.length === 0 ) ? "" :gdjs.Square_32PyramidCode.GDWidthObjects1[0].getBehavior("Text").getText())))) > 0);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = ((gdjs.evtTools.common.toNumber(((( gdjs.Square_32PyramidCode.GDLengthObjects1.length === 0 ) ? "" :gdjs.Square_32PyramidCode.GDLengthObjects1[0].getBehavior("Text").getText())))) > 0);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.Square_32PyramidCode.GDAnswerButtonObjects1_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
isConditionTrue_2 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("AnswerButton"), gdjs.Square_32PyramidCode.GDAnswerButtonObjects2);
for (var i = 0, k = 0, l = gdjs.Square_32PyramidCode.GDAnswerButtonObjects2.length;i<l;++i) {
    if ( gdjs.Square_32PyramidCode.GDAnswerButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_2 = true;
        gdjs.Square_32PyramidCode.GDAnswerButtonObjects2[k] = gdjs.Square_32PyramidCode.GDAnswerButtonObjects2[i];
        ++k;
    }
}
gdjs.Square_32PyramidCode.GDAnswerButtonObjects2.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Square_32PyramidCode.GDAnswerButtonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Square_32PyramidCode.GDAnswerButtonObjects1_2final.indexOf(gdjs.Square_32PyramidCode.GDAnswerButtonObjects2[j]) === -1 )
            gdjs.Square_32PyramidCode.GDAnswerButtonObjects1_2final.push(gdjs.Square_32PyramidCode.GDAnswerButtonObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Square_32PyramidCode.GDAnswerButtonObjects1_2final, gdjs.Square_32PyramidCode.GDAnswerButtonObjects1);
}
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Answer"), gdjs.Square_32PyramidCode.GDAnswerObjects1);
/* Reuse gdjs.Square_32PyramidCode.GDLengthObjects1 */
gdjs.copyArray(runtimeScene.getObjects("SquareBasedPyramid"), gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1);
/* Reuse gdjs.Square_32PyramidCode.GDWidthObjects1 */
/* Reuse gdjs.Square_32PyramidCode.GDheightObjects1 */
gdjs.copyArray(runtimeScene.getObjects("unit"), gdjs.Square_32PyramidCode.GDunitObjects1);
{for(var i = 0, len = gdjs.Square_32PyramidCode.GDAnswerObjects1.length ;i < len;++i) {
    gdjs.Square_32PyramidCode.GDAnswerObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.common.toNumber(((( gdjs.Square_32PyramidCode.GDheightObjects1.length === 0 ) ? "" :gdjs.Square_32PyramidCode.GDheightObjects1[0].getBehavior("Text").getText()))) * gdjs.evtTools.common.toNumber((( gdjs.Square_32PyramidCode.GDWidthObjects1.length === 0 ) ? "" :gdjs.Square_32PyramidCode.GDWidthObjects1[0].getBehavior("Text").getText())) * gdjs.evtTools.common.toNumber(((( gdjs.Square_32PyramidCode.GDLengthObjects1.length === 0 ) ? "" :gdjs.Square_32PyramidCode.GDLengthObjects1[0].getBehavior("Text").getText()))) / 3) + (( gdjs.Square_32PyramidCode.GDunitObjects1.length === 0 ) ? "" :gdjs.Square_32PyramidCode.GDunitObjects1[0].getBehavior("Text").getText()) + ((gdjs.Square_32PyramidCode.GDunitObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Square_32PyramidCode.GDunitObjects1[0].getVariables()).getFromIndex(0).getAsString());
}
}{for(var i = 0, len = gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1.length ;i < len;++i) {
    gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1[i].getBehavior("Resizable").setSize(gdjs.evtTools.common.toNumber(((( gdjs.Square_32PyramidCode.GDWidthObjects1.length === 0 ) ? "" :gdjs.Square_32PyramidCode.GDWidthObjects1[0].getBehavior("Text").getText()))) * 10, gdjs.evtTools.common.toNumber(((( gdjs.Square_32PyramidCode.GDheightObjects1.length === 0 ) ? "" :gdjs.Square_32PyramidCode.GDheightObjects1[0].getBehavior("Text").getText()))) * 10);
}
}{for(var i = 0, len = gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1.length ;i < len;++i) {
    gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1[i].getBehavior("Object3D").setDepth(gdjs.evtTools.common.toNumber((( gdjs.Square_32PyramidCode.GDLengthObjects1.length === 0 ) ? "" :gdjs.Square_32PyramidCode.GDLengthObjects1[0].getBehavior("Text").getText())) * 10);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SquareBasedPyramid"), gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1);
{for(var i = 0, len = gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1.length ;i < len;++i) {
    gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1[i].getBehavior("Object3D").turnAroundX(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SquareBasedPyramid"), gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1);
{for(var i = 0, len = gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1.length ;i < len;++i) {
    gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1[i].getBehavior("Object3D").turnAroundY(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SquareBasedPyramid"), gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1);
{for(var i = 0, len = gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1.length ;i < len;++i) {
    gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1[i].getBehavior("Object3D").turnAroundY(-(3));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SquareBasedPyramid"), gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1);
{for(var i = 0, len = gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1.length ;i < len;++i) {
    gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1[i].getBehavior("Object3D").turnAroundX(-(3));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Dash");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SquareBasedPyramid"), gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1);
{for(var i = 0, len = gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1.length ;i < len;++i) {
    gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1[i].getBehavior("Scale").setScaleX(gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1[i].getBehavior("Scale").getScaleX() / (1.009));
}
}{for(var i = 0, len = gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1.length ;i < len;++i) {
    gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1[i].getBehavior("Scale").setScaleY(gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1[i].getBehavior("Scale").getScaleY() / (1.009));
}
}{for(var i = 0, len = gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1.length ;i < len;++i) {
    gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1[i].getBehavior("Object3D").setScaleZ(gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1[i].getBehavior("Object3D").getScaleZ() / (1.009));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Equal");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SquareBasedPyramid"), gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1);
{for(var i = 0, len = gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1.length ;i < len;++i) {
    gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1[i].getBehavior("Scale").setScaleX(gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1[i].getBehavior("Scale").getScaleX() * (1.009));
}
}{for(var i = 0, len = gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1.length ;i < len;++i) {
    gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1[i].getBehavior("Object3D").setScaleZ(gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1[i].getBehavior("Object3D").getScaleZ() * (1.009));
}
}{for(var i = 0, len = gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1.length ;i < len;++i) {
    gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1[i].getBehavior("Scale").setScaleY(gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1[i].getBehavior("Scale").getScaleY() * (1.009));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LShift");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SquareBasedPyramid"), gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1);
{for(var i = 0, len = gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1.length ;i < len;++i) {
    gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1[i].getBehavior("Object3D").turnAroundZ(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LControl");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("SquareBasedPyramid"), gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1);
{for(var i = 0, len = gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1.length ;i < len;++i) {
    gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1[i].getBehavior("Object3D").turnAroundZ(-(3));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BackNewButton"), gdjs.Square_32PyramidCode.GDBackNewButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Square_32PyramidCode.GDBackNewButtonObjects1.length;i<l;++i) {
    if ( gdjs.Square_32PyramidCode.GDBackNewButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Square_32PyramidCode.GDBackNewButtonObjects1[k] = gdjs.Square_32PyramidCode.GDBackNewButtonObjects1[i];
        ++k;
    }
}
gdjs.Square_32PyramidCode.GDBackNewButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


};

gdjs.Square_32PyramidCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1.length = 0;
gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects2.length = 0;
gdjs.Square_32PyramidCode.GDheightObjects1.length = 0;
gdjs.Square_32PyramidCode.GDheightObjects2.length = 0;
gdjs.Square_32PyramidCode.GDWidthObjects1.length = 0;
gdjs.Square_32PyramidCode.GDWidthObjects2.length = 0;
gdjs.Square_32PyramidCode.GDLengthObjects1.length = 0;
gdjs.Square_32PyramidCode.GDLengthObjects2.length = 0;
gdjs.Square_32PyramidCode.GDAnswerObjects1.length = 0;
gdjs.Square_32PyramidCode.GDAnswerObjects2.length = 0;
gdjs.Square_32PyramidCode.GDunitObjects1.length = 0;
gdjs.Square_32PyramidCode.GDunitObjects2.length = 0;
gdjs.Square_32PyramidCode.GDBackNewButtonObjects1.length = 0;
gdjs.Square_32PyramidCode.GDBackNewButtonObjects2.length = 0;
gdjs.Square_32PyramidCode.GDControlsObjects1.length = 0;
gdjs.Square_32PyramidCode.GDControlsObjects2.length = 0;
gdjs.Square_32PyramidCode.GDAnswerButtonObjects1.length = 0;
gdjs.Square_32PyramidCode.GDAnswerButtonObjects2.length = 0;

gdjs.Square_32PyramidCode.eventsList0(runtimeScene);
gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects1.length = 0;
gdjs.Square_32PyramidCode.GDSquareBasedPyramidObjects2.length = 0;
gdjs.Square_32PyramidCode.GDheightObjects1.length = 0;
gdjs.Square_32PyramidCode.GDheightObjects2.length = 0;
gdjs.Square_32PyramidCode.GDWidthObjects1.length = 0;
gdjs.Square_32PyramidCode.GDWidthObjects2.length = 0;
gdjs.Square_32PyramidCode.GDLengthObjects1.length = 0;
gdjs.Square_32PyramidCode.GDLengthObjects2.length = 0;
gdjs.Square_32PyramidCode.GDAnswerObjects1.length = 0;
gdjs.Square_32PyramidCode.GDAnswerObjects2.length = 0;
gdjs.Square_32PyramidCode.GDunitObjects1.length = 0;
gdjs.Square_32PyramidCode.GDunitObjects2.length = 0;
gdjs.Square_32PyramidCode.GDBackNewButtonObjects1.length = 0;
gdjs.Square_32PyramidCode.GDBackNewButtonObjects2.length = 0;
gdjs.Square_32PyramidCode.GDControlsObjects1.length = 0;
gdjs.Square_32PyramidCode.GDControlsObjects2.length = 0;
gdjs.Square_32PyramidCode.GDAnswerButtonObjects1.length = 0;
gdjs.Square_32PyramidCode.GDAnswerButtonObjects2.length = 0;


return;

}

gdjs['Square_32PyramidCode'] = gdjs.Square_32PyramidCode;
