gdjs.CubeCode = {};
gdjs.CubeCode.localVariables = [];
gdjs.CubeCode.GDAnswerButtonObjects1_2final = [];

gdjs.CubeCode.GDCubeBricksObjects1= [];
gdjs.CubeCode.GDCubeBricksObjects2= [];
gdjs.CubeCode.GDheightObjects1= [];
gdjs.CubeCode.GDheightObjects2= [];
gdjs.CubeCode.GDWidthObjects1= [];
gdjs.CubeCode.GDWidthObjects2= [];
gdjs.CubeCode.GDLengthObjects1= [];
gdjs.CubeCode.GDLengthObjects2= [];
gdjs.CubeCode.GDAnswerObjects1= [];
gdjs.CubeCode.GDAnswerObjects2= [];
gdjs.CubeCode.GDunitObjects1= [];
gdjs.CubeCode.GDunitObjects2= [];
gdjs.CubeCode.GDBackNewButtonObjects1= [];
gdjs.CubeCode.GDBackNewButtonObjects2= [];
gdjs.CubeCode.GDControlsObjects1= [];
gdjs.CubeCode.GDControlsObjects2= [];
gdjs.CubeCode.GDAnswerButtonObjects1= [];
gdjs.CubeCode.GDAnswerButtonObjects2= [];


gdjs.CubeCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Length"), gdjs.CubeCode.GDLengthObjects1);
gdjs.copyArray(runtimeScene.getObjects("Width"), gdjs.CubeCode.GDWidthObjects1);
gdjs.copyArray(runtimeScene.getObjects("height"), gdjs.CubeCode.GDheightObjects1);
gdjs.CubeCode.GDAnswerButtonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
{isConditionTrue_1 = ((gdjs.evtTools.common.toNumber(((( gdjs.CubeCode.GDheightObjects1.length === 0 ) ? "" :gdjs.CubeCode.GDheightObjects1[0].getBehavior("Text").getText())))) > 0);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = ((gdjs.evtTools.common.toNumber(((( gdjs.CubeCode.GDWidthObjects1.length === 0 ) ? "" :gdjs.CubeCode.GDWidthObjects1[0].getBehavior("Text").getText())))) > 0);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = ((gdjs.evtTools.common.toNumber(((( gdjs.CubeCode.GDLengthObjects1.length === 0 ) ? "" :gdjs.CubeCode.GDLengthObjects1[0].getBehavior("Text").getText())))) > 0);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.CubeCode.GDAnswerButtonObjects1_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
isConditionTrue_2 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("AnswerButton"), gdjs.CubeCode.GDAnswerButtonObjects2);
for (var i = 0, k = 0, l = gdjs.CubeCode.GDAnswerButtonObjects2.length;i<l;++i) {
    if ( gdjs.CubeCode.GDAnswerButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_2 = true;
        gdjs.CubeCode.GDAnswerButtonObjects2[k] = gdjs.CubeCode.GDAnswerButtonObjects2[i];
        ++k;
    }
}
gdjs.CubeCode.GDAnswerButtonObjects2.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.CubeCode.GDAnswerButtonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.CubeCode.GDAnswerButtonObjects1_2final.indexOf(gdjs.CubeCode.GDAnswerButtonObjects2[j]) === -1 )
            gdjs.CubeCode.GDAnswerButtonObjects1_2final.push(gdjs.CubeCode.GDAnswerButtonObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.CubeCode.GDAnswerButtonObjects1_2final, gdjs.CubeCode.GDAnswerButtonObjects1);
}
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Answer"), gdjs.CubeCode.GDAnswerObjects1);
gdjs.copyArray(runtimeScene.getObjects("CubeBricks"), gdjs.CubeCode.GDCubeBricksObjects1);
/* Reuse gdjs.CubeCode.GDLengthObjects1 */
/* Reuse gdjs.CubeCode.GDWidthObjects1 */
/* Reuse gdjs.CubeCode.GDheightObjects1 */
gdjs.copyArray(runtimeScene.getObjects("unit"), gdjs.CubeCode.GDunitObjects1);
{for(var i = 0, len = gdjs.CubeCode.GDAnswerObjects1.length ;i < len;++i) {
    gdjs.CubeCode.GDAnswerObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.common.toNumber(((( gdjs.CubeCode.GDheightObjects1.length === 0 ) ? "" :gdjs.CubeCode.GDheightObjects1[0].getBehavior("Text").getText()))) * gdjs.evtTools.common.toNumber((( gdjs.CubeCode.GDWidthObjects1.length === 0 ) ? "" :gdjs.CubeCode.GDWidthObjects1[0].getBehavior("Text").getText())) * gdjs.evtTools.common.toNumber(((( gdjs.CubeCode.GDLengthObjects1.length === 0 ) ? "" :gdjs.CubeCode.GDLengthObjects1[0].getBehavior("Text").getText())))) + (( gdjs.CubeCode.GDunitObjects1.length === 0 ) ? "" :gdjs.CubeCode.GDunitObjects1[0].getBehavior("Text").getText()) + ((gdjs.CubeCode.GDunitObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.CubeCode.GDunitObjects1[0].getVariables()).getFromIndex(0).getAsString());
}
}{for(var i = 0, len = gdjs.CubeCode.GDCubeBricksObjects1.length ;i < len;++i) {
    gdjs.CubeCode.GDCubeBricksObjects1[i].getBehavior("Resizable").setSize(gdjs.evtTools.common.toNumber(((( gdjs.CubeCode.GDWidthObjects1.length === 0 ) ? "" :gdjs.CubeCode.GDWidthObjects1[0].getBehavior("Text").getText()))) * 10, gdjs.evtTools.common.toNumber(((( gdjs.CubeCode.GDheightObjects1.length === 0 ) ? "" :gdjs.CubeCode.GDheightObjects1[0].getBehavior("Text").getText()))) * 10);
}
}{for(var i = 0, len = gdjs.CubeCode.GDCubeBricksObjects1.length ;i < len;++i) {
    gdjs.CubeCode.GDCubeBricksObjects1[i].getBehavior("Object3D").setDepth(gdjs.evtTools.common.toNumber((( gdjs.CubeCode.GDLengthObjects1.length === 0 ) ? "" :gdjs.CubeCode.GDLengthObjects1[0].getBehavior("Text").getText())) * 10);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CubeBricks"), gdjs.CubeCode.GDCubeBricksObjects1);
{for(var i = 0, len = gdjs.CubeCode.GDCubeBricksObjects1.length ;i < len;++i) {
    gdjs.CubeCode.GDCubeBricksObjects1[i].getBehavior("Object3D").turnAroundX(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CubeBricks"), gdjs.CubeCode.GDCubeBricksObjects1);
{for(var i = 0, len = gdjs.CubeCode.GDCubeBricksObjects1.length ;i < len;++i) {
    gdjs.CubeCode.GDCubeBricksObjects1[i].getBehavior("Object3D").turnAroundY(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CubeBricks"), gdjs.CubeCode.GDCubeBricksObjects1);
{for(var i = 0, len = gdjs.CubeCode.GDCubeBricksObjects1.length ;i < len;++i) {
    gdjs.CubeCode.GDCubeBricksObjects1[i].getBehavior("Object3D").turnAroundY(-(3));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CubeBricks"), gdjs.CubeCode.GDCubeBricksObjects1);
{for(var i = 0, len = gdjs.CubeCode.GDCubeBricksObjects1.length ;i < len;++i) {
    gdjs.CubeCode.GDCubeBricksObjects1[i].getBehavior("Object3D").turnAroundX(-(3));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Dash");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CubeBricks"), gdjs.CubeCode.GDCubeBricksObjects1);
{for(var i = 0, len = gdjs.CubeCode.GDCubeBricksObjects1.length ;i < len;++i) {
    gdjs.CubeCode.GDCubeBricksObjects1[i].getBehavior("Scale").setScaleX(gdjs.CubeCode.GDCubeBricksObjects1[i].getBehavior("Scale").getScaleX() / (1.009));
}
}{for(var i = 0, len = gdjs.CubeCode.GDCubeBricksObjects1.length ;i < len;++i) {
    gdjs.CubeCode.GDCubeBricksObjects1[i].getBehavior("Scale").setScaleY(gdjs.CubeCode.GDCubeBricksObjects1[i].getBehavior("Scale").getScaleY() / (1.009));
}
}{for(var i = 0, len = gdjs.CubeCode.GDCubeBricksObjects1.length ;i < len;++i) {
    gdjs.CubeCode.GDCubeBricksObjects1[i].getBehavior("Object3D").setScaleZ(gdjs.CubeCode.GDCubeBricksObjects1[i].getBehavior("Object3D").getScaleZ() / (1.009));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Equal");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CubeBricks"), gdjs.CubeCode.GDCubeBricksObjects1);
{for(var i = 0, len = gdjs.CubeCode.GDCubeBricksObjects1.length ;i < len;++i) {
    gdjs.CubeCode.GDCubeBricksObjects1[i].getBehavior("Scale").setScaleX(gdjs.CubeCode.GDCubeBricksObjects1[i].getBehavior("Scale").getScaleX() * (1.009));
}
}{for(var i = 0, len = gdjs.CubeCode.GDCubeBricksObjects1.length ;i < len;++i) {
    gdjs.CubeCode.GDCubeBricksObjects1[i].getBehavior("Object3D").setScaleZ(gdjs.CubeCode.GDCubeBricksObjects1[i].getBehavior("Object3D").getScaleZ() * (1.009));
}
}{for(var i = 0, len = gdjs.CubeCode.GDCubeBricksObjects1.length ;i < len;++i) {
    gdjs.CubeCode.GDCubeBricksObjects1[i].getBehavior("Scale").setScaleY(gdjs.CubeCode.GDCubeBricksObjects1[i].getBehavior("Scale").getScaleY() * (1.009));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LShift");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CubeBricks"), gdjs.CubeCode.GDCubeBricksObjects1);
{for(var i = 0, len = gdjs.CubeCode.GDCubeBricksObjects1.length ;i < len;++i) {
    gdjs.CubeCode.GDCubeBricksObjects1[i].getBehavior("Object3D").turnAroundZ(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LControl");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CubeBricks"), gdjs.CubeCode.GDCubeBricksObjects1);
{for(var i = 0, len = gdjs.CubeCode.GDCubeBricksObjects1.length ;i < len;++i) {
    gdjs.CubeCode.GDCubeBricksObjects1[i].getBehavior("Object3D").turnAroundZ(-(3));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BackNewButton"), gdjs.CubeCode.GDBackNewButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.CubeCode.GDBackNewButtonObjects1.length;i<l;++i) {
    if ( gdjs.CubeCode.GDBackNewButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.CubeCode.GDBackNewButtonObjects1[k] = gdjs.CubeCode.GDBackNewButtonObjects1[i];
        ++k;
    }
}
gdjs.CubeCode.GDBackNewButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


};

gdjs.CubeCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.CubeCode.GDCubeBricksObjects1.length = 0;
gdjs.CubeCode.GDCubeBricksObjects2.length = 0;
gdjs.CubeCode.GDheightObjects1.length = 0;
gdjs.CubeCode.GDheightObjects2.length = 0;
gdjs.CubeCode.GDWidthObjects1.length = 0;
gdjs.CubeCode.GDWidthObjects2.length = 0;
gdjs.CubeCode.GDLengthObjects1.length = 0;
gdjs.CubeCode.GDLengthObjects2.length = 0;
gdjs.CubeCode.GDAnswerObjects1.length = 0;
gdjs.CubeCode.GDAnswerObjects2.length = 0;
gdjs.CubeCode.GDunitObjects1.length = 0;
gdjs.CubeCode.GDunitObjects2.length = 0;
gdjs.CubeCode.GDBackNewButtonObjects1.length = 0;
gdjs.CubeCode.GDBackNewButtonObjects2.length = 0;
gdjs.CubeCode.GDControlsObjects1.length = 0;
gdjs.CubeCode.GDControlsObjects2.length = 0;
gdjs.CubeCode.GDAnswerButtonObjects1.length = 0;
gdjs.CubeCode.GDAnswerButtonObjects2.length = 0;

gdjs.CubeCode.eventsList0(runtimeScene);
gdjs.CubeCode.GDCubeBricksObjects1.length = 0;
gdjs.CubeCode.GDCubeBricksObjects2.length = 0;
gdjs.CubeCode.GDheightObjects1.length = 0;
gdjs.CubeCode.GDheightObjects2.length = 0;
gdjs.CubeCode.GDWidthObjects1.length = 0;
gdjs.CubeCode.GDWidthObjects2.length = 0;
gdjs.CubeCode.GDLengthObjects1.length = 0;
gdjs.CubeCode.GDLengthObjects2.length = 0;
gdjs.CubeCode.GDAnswerObjects1.length = 0;
gdjs.CubeCode.GDAnswerObjects2.length = 0;
gdjs.CubeCode.GDunitObjects1.length = 0;
gdjs.CubeCode.GDunitObjects2.length = 0;
gdjs.CubeCode.GDBackNewButtonObjects1.length = 0;
gdjs.CubeCode.GDBackNewButtonObjects2.length = 0;
gdjs.CubeCode.GDControlsObjects1.length = 0;
gdjs.CubeCode.GDControlsObjects2.length = 0;
gdjs.CubeCode.GDAnswerButtonObjects1.length = 0;
gdjs.CubeCode.GDAnswerButtonObjects2.length = 0;


return;

}

gdjs['CubeCode'] = gdjs.CubeCode;
