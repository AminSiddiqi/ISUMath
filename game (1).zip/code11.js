gdjs.ConeCode = {};
gdjs.ConeCode.localVariables = [];
gdjs.ConeCode.GDAnswerButtonObjects1_2final = [];

gdjs.ConeCode.GDConeModelObjects1= [];
gdjs.ConeCode.GDConeModelObjects2= [];
gdjs.ConeCode.GDheightObjects1= [];
gdjs.ConeCode.GDheightObjects2= [];
gdjs.ConeCode.GDRadiusObjects1= [];
gdjs.ConeCode.GDRadiusObjects2= [];
gdjs.ConeCode.GDAnswerObjects1= [];
gdjs.ConeCode.GDAnswerObjects2= [];
gdjs.ConeCode.GDunitObjects1= [];
gdjs.ConeCode.GDunitObjects2= [];
gdjs.ConeCode.GDBackNewButtonObjects1= [];
gdjs.ConeCode.GDBackNewButtonObjects2= [];
gdjs.ConeCode.GDControlsObjects1= [];
gdjs.ConeCode.GDControlsObjects2= [];
gdjs.ConeCode.GDAnswerButtonObjects1= [];
gdjs.ConeCode.GDAnswerButtonObjects2= [];


gdjs.ConeCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Radius"), gdjs.ConeCode.GDRadiusObjects1);
gdjs.copyArray(runtimeScene.getObjects("height"), gdjs.ConeCode.GDheightObjects1);
gdjs.ConeCode.GDAnswerButtonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
{isConditionTrue_1 = ((gdjs.evtTools.common.toNumber((( gdjs.ConeCode.GDheightObjects1.length === 0 ) ? "" :gdjs.ConeCode.GDheightObjects1[0].getBehavior("Text").getText()))) > 0);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = ((gdjs.evtTools.common.toNumber((( gdjs.ConeCode.GDRadiusObjects1.length === 0 ) ? "" :gdjs.ConeCode.GDRadiusObjects1[0].getBehavior("Text").getText()))) > 0);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.ConeCode.GDAnswerButtonObjects1_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
isConditionTrue_2 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("AnswerButton"), gdjs.ConeCode.GDAnswerButtonObjects2);
for (var i = 0, k = 0, l = gdjs.ConeCode.GDAnswerButtonObjects2.length;i<l;++i) {
    if ( gdjs.ConeCode.GDAnswerButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_2 = true;
        gdjs.ConeCode.GDAnswerButtonObjects2[k] = gdjs.ConeCode.GDAnswerButtonObjects2[i];
        ++k;
    }
}
gdjs.ConeCode.GDAnswerButtonObjects2.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.ConeCode.GDAnswerButtonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.ConeCode.GDAnswerButtonObjects1_2final.indexOf(gdjs.ConeCode.GDAnswerButtonObjects2[j]) === -1 )
            gdjs.ConeCode.GDAnswerButtonObjects1_2final.push(gdjs.ConeCode.GDAnswerButtonObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.ConeCode.GDAnswerButtonObjects1_2final, gdjs.ConeCode.GDAnswerButtonObjects1);
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Answer"), gdjs.ConeCode.GDAnswerObjects1);
gdjs.copyArray(runtimeScene.getObjects("ConeModel"), gdjs.ConeCode.GDConeModelObjects1);
/* Reuse gdjs.ConeCode.GDRadiusObjects1 */
/* Reuse gdjs.ConeCode.GDheightObjects1 */
gdjs.copyArray(runtimeScene.getObjects("unit"), gdjs.ConeCode.GDunitObjects1);
{for(var i = 0, len = gdjs.ConeCode.GDConeModelObjects1.length ;i < len;++i) {
    gdjs.ConeCode.GDConeModelObjects1[i].getBehavior("Object3D").setDepth(gdjs.evtTools.common.toNumber((( gdjs.ConeCode.GDRadiusObjects1.length === 0 ) ? "" :gdjs.ConeCode.GDRadiusObjects1[0].getBehavior("Text").getText())) * 2);
}
}{for(var i = 0, len = gdjs.ConeCode.GDConeModelObjects1.length ;i < len;++i) {
    gdjs.ConeCode.GDConeModelObjects1[i].getBehavior("Scale").setScaleX(gdjs.evtTools.common.toNumber((( gdjs.ConeCode.GDRadiusObjects1.length === 0 ) ? "" :gdjs.ConeCode.GDRadiusObjects1[0].getBehavior("Text").getText())) * 2);
}
}{for(var i = 0, len = gdjs.ConeCode.GDConeModelObjects1.length ;i < len;++i) {
    gdjs.ConeCode.GDConeModelObjects1[i].getBehavior("Scale").setScaleY(gdjs.evtTools.common.toNumber((( gdjs.ConeCode.GDRadiusObjects1.length === 0 ) ? "" :gdjs.ConeCode.GDRadiusObjects1[0].getBehavior("Text").getText())) * 2);
}
}{for(var i = 0, len = gdjs.ConeCode.GDAnswerObjects1.length ;i < len;++i) {
    gdjs.ConeCode.GDAnswerObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.common.roundTo(gdjs.evtTools.common.toNumber((( gdjs.ConeCode.GDRadiusObjects1.length === 0 ) ? "" :gdjs.ConeCode.GDRadiusObjects1[0].getBehavior("Text").getText())) * (gdjs.evtTools.common.toNumber((( gdjs.ConeCode.GDRadiusObjects1.length === 0 ) ? "" :gdjs.ConeCode.GDRadiusObjects1[0].getBehavior("Text").getText()))) * 3.141 * (gdjs.evtTools.common.toNumber((( gdjs.ConeCode.GDheightObjects1.length === 0 ) ? "" :gdjs.ConeCode.GDheightObjects1[0].getBehavior("Text").getText())) / 3), 3)) + (( gdjs.ConeCode.GDunitObjects1.length === 0 ) ? "" :gdjs.ConeCode.GDunitObjects1[0].getBehavior("Text").getText()) + ((gdjs.ConeCode.GDunitObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ConeCode.GDunitObjects1[0].getVariables()).getFromIndex(0).getAsString());
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ConeModel"), gdjs.ConeCode.GDConeModelObjects1);
{for(var i = 0, len = gdjs.ConeCode.GDConeModelObjects1.length ;i < len;++i) {
    gdjs.ConeCode.GDConeModelObjects1[i].getBehavior("Object3D").turnAroundX(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ConeModel"), gdjs.ConeCode.GDConeModelObjects1);
{for(var i = 0, len = gdjs.ConeCode.GDConeModelObjects1.length ;i < len;++i) {
    gdjs.ConeCode.GDConeModelObjects1[i].getBehavior("Object3D").turnAroundY(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ConeModel"), gdjs.ConeCode.GDConeModelObjects1);
{for(var i = 0, len = gdjs.ConeCode.GDConeModelObjects1.length ;i < len;++i) {
    gdjs.ConeCode.GDConeModelObjects1[i].getBehavior("Object3D").turnAroundY(-(3));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ConeModel"), gdjs.ConeCode.GDConeModelObjects1);
{for(var i = 0, len = gdjs.ConeCode.GDConeModelObjects1.length ;i < len;++i) {
    gdjs.ConeCode.GDConeModelObjects1[i].getBehavior("Object3D").turnAroundX(-(3));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Dash");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ConeModel"), gdjs.ConeCode.GDConeModelObjects1);
{for(var i = 0, len = gdjs.ConeCode.GDConeModelObjects1.length ;i < len;++i) {
    gdjs.ConeCode.GDConeModelObjects1[i].getBehavior("Scale").setScaleX(gdjs.ConeCode.GDConeModelObjects1[i].getBehavior("Scale").getScaleX() / (1.009));
}
}{for(var i = 0, len = gdjs.ConeCode.GDConeModelObjects1.length ;i < len;++i) {
    gdjs.ConeCode.GDConeModelObjects1[i].getBehavior("Scale").setScaleY(gdjs.ConeCode.GDConeModelObjects1[i].getBehavior("Scale").getScaleY() / (1.009));
}
}{for(var i = 0, len = gdjs.ConeCode.GDConeModelObjects1.length ;i < len;++i) {
    gdjs.ConeCode.GDConeModelObjects1[i].getBehavior("Object3D").setScaleZ(gdjs.ConeCode.GDConeModelObjects1[i].getBehavior("Object3D").getScaleZ() / (1.009));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Equal");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ConeModel"), gdjs.ConeCode.GDConeModelObjects1);
{for(var i = 0, len = gdjs.ConeCode.GDConeModelObjects1.length ;i < len;++i) {
    gdjs.ConeCode.GDConeModelObjects1[i].getBehavior("Scale").setScaleX(gdjs.ConeCode.GDConeModelObjects1[i].getBehavior("Scale").getScaleX() * (1.009));
}
}{for(var i = 0, len = gdjs.ConeCode.GDConeModelObjects1.length ;i < len;++i) {
    gdjs.ConeCode.GDConeModelObjects1[i].getBehavior("Object3D").setScaleZ(gdjs.ConeCode.GDConeModelObjects1[i].getBehavior("Object3D").getScaleZ() * (1.009));
}
}{for(var i = 0, len = gdjs.ConeCode.GDConeModelObjects1.length ;i < len;++i) {
    gdjs.ConeCode.GDConeModelObjects1[i].getBehavior("Scale").setScaleY(gdjs.ConeCode.GDConeModelObjects1[i].getBehavior("Scale").getScaleY() * (1.009));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LShift");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ConeModel"), gdjs.ConeCode.GDConeModelObjects1);
{for(var i = 0, len = gdjs.ConeCode.GDConeModelObjects1.length ;i < len;++i) {
    gdjs.ConeCode.GDConeModelObjects1[i].getBehavior("Object3D").turnAroundZ(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LControl");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ConeModel"), gdjs.ConeCode.GDConeModelObjects1);
{for(var i = 0, len = gdjs.ConeCode.GDConeModelObjects1.length ;i < len;++i) {
    gdjs.ConeCode.GDConeModelObjects1[i].getBehavior("Object3D").turnAroundZ(-(3));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BackNewButton"), gdjs.ConeCode.GDBackNewButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ConeCode.GDBackNewButtonObjects1.length;i<l;++i) {
    if ( gdjs.ConeCode.GDBackNewButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.ConeCode.GDBackNewButtonObjects1[k] = gdjs.ConeCode.GDBackNewButtonObjects1[i];
        ++k;
    }
}
gdjs.ConeCode.GDBackNewButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


};

gdjs.ConeCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.ConeCode.GDConeModelObjects1.length = 0;
gdjs.ConeCode.GDConeModelObjects2.length = 0;
gdjs.ConeCode.GDheightObjects1.length = 0;
gdjs.ConeCode.GDheightObjects2.length = 0;
gdjs.ConeCode.GDRadiusObjects1.length = 0;
gdjs.ConeCode.GDRadiusObjects2.length = 0;
gdjs.ConeCode.GDAnswerObjects1.length = 0;
gdjs.ConeCode.GDAnswerObjects2.length = 0;
gdjs.ConeCode.GDunitObjects1.length = 0;
gdjs.ConeCode.GDunitObjects2.length = 0;
gdjs.ConeCode.GDBackNewButtonObjects1.length = 0;
gdjs.ConeCode.GDBackNewButtonObjects2.length = 0;
gdjs.ConeCode.GDControlsObjects1.length = 0;
gdjs.ConeCode.GDControlsObjects2.length = 0;
gdjs.ConeCode.GDAnswerButtonObjects1.length = 0;
gdjs.ConeCode.GDAnswerButtonObjects2.length = 0;

gdjs.ConeCode.eventsList0(runtimeScene);
gdjs.ConeCode.GDConeModelObjects1.length = 0;
gdjs.ConeCode.GDConeModelObjects2.length = 0;
gdjs.ConeCode.GDheightObjects1.length = 0;
gdjs.ConeCode.GDheightObjects2.length = 0;
gdjs.ConeCode.GDRadiusObjects1.length = 0;
gdjs.ConeCode.GDRadiusObjects2.length = 0;
gdjs.ConeCode.GDAnswerObjects1.length = 0;
gdjs.ConeCode.GDAnswerObjects2.length = 0;
gdjs.ConeCode.GDunitObjects1.length = 0;
gdjs.ConeCode.GDunitObjects2.length = 0;
gdjs.ConeCode.GDBackNewButtonObjects1.length = 0;
gdjs.ConeCode.GDBackNewButtonObjects2.length = 0;
gdjs.ConeCode.GDControlsObjects1.length = 0;
gdjs.ConeCode.GDControlsObjects2.length = 0;
gdjs.ConeCode.GDAnswerButtonObjects1.length = 0;
gdjs.ConeCode.GDAnswerButtonObjects2.length = 0;


return;

}

gdjs['ConeCode'] = gdjs.ConeCode;
