gdjs.Triangle_32PyramidCode = {};
gdjs.Triangle_32PyramidCode.localVariables = [];
gdjs.Triangle_32PyramidCode.GDAnswerButtonObjects1_2final = [];

gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1= [];
gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects2= [];
gdjs.Triangle_32PyramidCode.GDheightObjects1= [];
gdjs.Triangle_32PyramidCode.GDheightObjects2= [];
gdjs.Triangle_32PyramidCode.GDWidthObjects1= [];
gdjs.Triangle_32PyramidCode.GDWidthObjects2= [];
gdjs.Triangle_32PyramidCode.GDLengthObjects1= [];
gdjs.Triangle_32PyramidCode.GDLengthObjects2= [];
gdjs.Triangle_32PyramidCode.GDAnswerObjects1= [];
gdjs.Triangle_32PyramidCode.GDAnswerObjects2= [];
gdjs.Triangle_32PyramidCode.GDunitObjects1= [];
gdjs.Triangle_32PyramidCode.GDunitObjects2= [];
gdjs.Triangle_32PyramidCode.GDBackNewButtonObjects1= [];
gdjs.Triangle_32PyramidCode.GDBackNewButtonObjects2= [];
gdjs.Triangle_32PyramidCode.GDControlsObjects1= [];
gdjs.Triangle_32PyramidCode.GDControlsObjects2= [];
gdjs.Triangle_32PyramidCode.GDAnswerButtonObjects1= [];
gdjs.Triangle_32PyramidCode.GDAnswerButtonObjects2= [];


gdjs.Triangle_32PyramidCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Length"), gdjs.Triangle_32PyramidCode.GDLengthObjects1);
gdjs.copyArray(runtimeScene.getObjects("Width"), gdjs.Triangle_32PyramidCode.GDWidthObjects1);
gdjs.copyArray(runtimeScene.getObjects("height"), gdjs.Triangle_32PyramidCode.GDheightObjects1);
gdjs.Triangle_32PyramidCode.GDAnswerButtonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
{isConditionTrue_1 = ((gdjs.evtTools.common.toNumber(((( gdjs.Triangle_32PyramidCode.GDheightObjects1.length === 0 ) ? "" :gdjs.Triangle_32PyramidCode.GDheightObjects1[0].getBehavior("Text").getText())))) > 0);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = ((gdjs.evtTools.common.toNumber(((( gdjs.Triangle_32PyramidCode.GDWidthObjects1.length === 0 ) ? "" :gdjs.Triangle_32PyramidCode.GDWidthObjects1[0].getBehavior("Text").getText())))) > 0);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = ((gdjs.evtTools.common.toNumber(((( gdjs.Triangle_32PyramidCode.GDLengthObjects1.length === 0 ) ? "" :gdjs.Triangle_32PyramidCode.GDLengthObjects1[0].getBehavior("Text").getText())))) > 0);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.Triangle_32PyramidCode.GDAnswerButtonObjects1_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
isConditionTrue_2 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("AnswerButton"), gdjs.Triangle_32PyramidCode.GDAnswerButtonObjects2);
for (var i = 0, k = 0, l = gdjs.Triangle_32PyramidCode.GDAnswerButtonObjects2.length;i<l;++i) {
    if ( gdjs.Triangle_32PyramidCode.GDAnswerButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_2 = true;
        gdjs.Triangle_32PyramidCode.GDAnswerButtonObjects2[k] = gdjs.Triangle_32PyramidCode.GDAnswerButtonObjects2[i];
        ++k;
    }
}
gdjs.Triangle_32PyramidCode.GDAnswerButtonObjects2.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Triangle_32PyramidCode.GDAnswerButtonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Triangle_32PyramidCode.GDAnswerButtonObjects1_2final.indexOf(gdjs.Triangle_32PyramidCode.GDAnswerButtonObjects2[j]) === -1 )
            gdjs.Triangle_32PyramidCode.GDAnswerButtonObjects1_2final.push(gdjs.Triangle_32PyramidCode.GDAnswerButtonObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Triangle_32PyramidCode.GDAnswerButtonObjects1_2final, gdjs.Triangle_32PyramidCode.GDAnswerButtonObjects1);
}
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Answer"), gdjs.Triangle_32PyramidCode.GDAnswerObjects1);
/* Reuse gdjs.Triangle_32PyramidCode.GDLengthObjects1 */
gdjs.copyArray(runtimeScene.getObjects("TriangularPyramid"), gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1);
/* Reuse gdjs.Triangle_32PyramidCode.GDWidthObjects1 */
/* Reuse gdjs.Triangle_32PyramidCode.GDheightObjects1 */
gdjs.copyArray(runtimeScene.getObjects("unit"), gdjs.Triangle_32PyramidCode.GDunitObjects1);
{for(var i = 0, len = gdjs.Triangle_32PyramidCode.GDAnswerObjects1.length ;i < len;++i) {
    gdjs.Triangle_32PyramidCode.GDAnswerObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.common.toNumber(((( gdjs.Triangle_32PyramidCode.GDheightObjects1.length === 0 ) ? "" :gdjs.Triangle_32PyramidCode.GDheightObjects1[0].getBehavior("Text").getText()))) * gdjs.evtTools.common.toNumber((( gdjs.Triangle_32PyramidCode.GDWidthObjects1.length === 0 ) ? "" :gdjs.Triangle_32PyramidCode.GDWidthObjects1[0].getBehavior("Text").getText())) * gdjs.evtTools.common.toNumber(((( gdjs.Triangle_32PyramidCode.GDLengthObjects1.length === 0 ) ? "" :gdjs.Triangle_32PyramidCode.GDLengthObjects1[0].getBehavior("Text").getText()))) / 2 / 3) + (( gdjs.Triangle_32PyramidCode.GDunitObjects1.length === 0 ) ? "" :gdjs.Triangle_32PyramidCode.GDunitObjects1[0].getBehavior("Text").getText()) + ((gdjs.Triangle_32PyramidCode.GDunitObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Triangle_32PyramidCode.GDunitObjects1[0].getVariables()).getFromIndex(0).getAsString());
}
}{for(var i = 0, len = gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1.length ;i < len;++i) {
    gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1[i].getBehavior("Resizable").setSize(gdjs.evtTools.common.toNumber(((( gdjs.Triangle_32PyramidCode.GDWidthObjects1.length === 0 ) ? "" :gdjs.Triangle_32PyramidCode.GDWidthObjects1[0].getBehavior("Text").getText()))) * 10, gdjs.evtTools.common.toNumber(((( gdjs.Triangle_32PyramidCode.GDheightObjects1.length === 0 ) ? "" :gdjs.Triangle_32PyramidCode.GDheightObjects1[0].getBehavior("Text").getText()))) * 10);
}
}{for(var i = 0, len = gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1.length ;i < len;++i) {
    gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1[i].getBehavior("Object3D").setDepth(gdjs.evtTools.common.toNumber((( gdjs.Triangle_32PyramidCode.GDLengthObjects1.length === 0 ) ? "" :gdjs.Triangle_32PyramidCode.GDLengthObjects1[0].getBehavior("Text").getText())) * 10);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TriangularPyramid"), gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1);
{for(var i = 0, len = gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1.length ;i < len;++i) {
    gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1[i].getBehavior("Object3D").turnAroundX(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TriangularPyramid"), gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1);
{for(var i = 0, len = gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1.length ;i < len;++i) {
    gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1[i].getBehavior("Object3D").turnAroundY(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TriangularPyramid"), gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1);
{for(var i = 0, len = gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1.length ;i < len;++i) {
    gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1[i].getBehavior("Object3D").turnAroundY(-(3));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TriangularPyramid"), gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1);
{for(var i = 0, len = gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1.length ;i < len;++i) {
    gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1[i].getBehavior("Object3D").turnAroundX(-(3));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Dash");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TriangularPyramid"), gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1);
{for(var i = 0, len = gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1.length ;i < len;++i) {
    gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1[i].getBehavior("Scale").setScaleX(gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1[i].getBehavior("Scale").getScaleX() / (1.009));
}
}{for(var i = 0, len = gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1.length ;i < len;++i) {
    gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1[i].getBehavior("Scale").setScaleY(gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1[i].getBehavior("Scale").getScaleY() / (1.009));
}
}{for(var i = 0, len = gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1.length ;i < len;++i) {
    gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1[i].getBehavior("Object3D").setScaleZ(gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1[i].getBehavior("Object3D").getScaleZ() / (1.009));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Equal");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TriangularPyramid"), gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1);
{for(var i = 0, len = gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1.length ;i < len;++i) {
    gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1[i].getBehavior("Scale").setScaleX(gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1[i].getBehavior("Scale").getScaleX() * (1.009));
}
}{for(var i = 0, len = gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1.length ;i < len;++i) {
    gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1[i].getBehavior("Object3D").setScaleZ(gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1[i].getBehavior("Object3D").getScaleZ() * (1.009));
}
}{for(var i = 0, len = gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1.length ;i < len;++i) {
    gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1[i].getBehavior("Scale").setScaleY(gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1[i].getBehavior("Scale").getScaleY() * (1.009));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LShift");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TriangularPyramid"), gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1);
{for(var i = 0, len = gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1.length ;i < len;++i) {
    gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1[i].getBehavior("Object3D").turnAroundZ(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LControl");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TriangularPyramid"), gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1);
{for(var i = 0, len = gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1.length ;i < len;++i) {
    gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1[i].getBehavior("Object3D").turnAroundZ(-(3));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BackNewButton"), gdjs.Triangle_32PyramidCode.GDBackNewButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Triangle_32PyramidCode.GDBackNewButtonObjects1.length;i<l;++i) {
    if ( gdjs.Triangle_32PyramidCode.GDBackNewButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Triangle_32PyramidCode.GDBackNewButtonObjects1[k] = gdjs.Triangle_32PyramidCode.GDBackNewButtonObjects1[i];
        ++k;
    }
}
gdjs.Triangle_32PyramidCode.GDBackNewButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


};

gdjs.Triangle_32PyramidCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1.length = 0;
gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects2.length = 0;
gdjs.Triangle_32PyramidCode.GDheightObjects1.length = 0;
gdjs.Triangle_32PyramidCode.GDheightObjects2.length = 0;
gdjs.Triangle_32PyramidCode.GDWidthObjects1.length = 0;
gdjs.Triangle_32PyramidCode.GDWidthObjects2.length = 0;
gdjs.Triangle_32PyramidCode.GDLengthObjects1.length = 0;
gdjs.Triangle_32PyramidCode.GDLengthObjects2.length = 0;
gdjs.Triangle_32PyramidCode.GDAnswerObjects1.length = 0;
gdjs.Triangle_32PyramidCode.GDAnswerObjects2.length = 0;
gdjs.Triangle_32PyramidCode.GDunitObjects1.length = 0;
gdjs.Triangle_32PyramidCode.GDunitObjects2.length = 0;
gdjs.Triangle_32PyramidCode.GDBackNewButtonObjects1.length = 0;
gdjs.Triangle_32PyramidCode.GDBackNewButtonObjects2.length = 0;
gdjs.Triangle_32PyramidCode.GDControlsObjects1.length = 0;
gdjs.Triangle_32PyramidCode.GDControlsObjects2.length = 0;
gdjs.Triangle_32PyramidCode.GDAnswerButtonObjects1.length = 0;
gdjs.Triangle_32PyramidCode.GDAnswerButtonObjects2.length = 0;

gdjs.Triangle_32PyramidCode.eventsList0(runtimeScene);
gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects1.length = 0;
gdjs.Triangle_32PyramidCode.GDTriangularPyramidObjects2.length = 0;
gdjs.Triangle_32PyramidCode.GDheightObjects1.length = 0;
gdjs.Triangle_32PyramidCode.GDheightObjects2.length = 0;
gdjs.Triangle_32PyramidCode.GDWidthObjects1.length = 0;
gdjs.Triangle_32PyramidCode.GDWidthObjects2.length = 0;
gdjs.Triangle_32PyramidCode.GDLengthObjects1.length = 0;
gdjs.Triangle_32PyramidCode.GDLengthObjects2.length = 0;
gdjs.Triangle_32PyramidCode.GDAnswerObjects1.length = 0;
gdjs.Triangle_32PyramidCode.GDAnswerObjects2.length = 0;
gdjs.Triangle_32PyramidCode.GDunitObjects1.length = 0;
gdjs.Triangle_32PyramidCode.GDunitObjects2.length = 0;
gdjs.Triangle_32PyramidCode.GDBackNewButtonObjects1.length = 0;
gdjs.Triangle_32PyramidCode.GDBackNewButtonObjects2.length = 0;
gdjs.Triangle_32PyramidCode.GDControlsObjects1.length = 0;
gdjs.Triangle_32PyramidCode.GDControlsObjects2.length = 0;
gdjs.Triangle_32PyramidCode.GDAnswerButtonObjects1.length = 0;
gdjs.Triangle_32PyramidCode.GDAnswerButtonObjects2.length = 0;


return;

}

gdjs['Triangle_32PyramidCode'] = gdjs.Triangle_32PyramidCode;
