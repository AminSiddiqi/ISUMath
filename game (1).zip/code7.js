gdjs.Triangular_32PrismCode = {};
gdjs.Triangular_32PrismCode.localVariables = [];
gdjs.Triangular_32PrismCode.GDAnswerButtonObjects1_2final = [];

gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1= [];
gdjs.Triangular_32PrismCode.GDTriangularPrismObjects2= [];
gdjs.Triangular_32PrismCode.GDheightObjects1= [];
gdjs.Triangular_32PrismCode.GDheightObjects2= [];
gdjs.Triangular_32PrismCode.GDWidthObjects1= [];
gdjs.Triangular_32PrismCode.GDWidthObjects2= [];
gdjs.Triangular_32PrismCode.GDLengthObjects1= [];
gdjs.Triangular_32PrismCode.GDLengthObjects2= [];
gdjs.Triangular_32PrismCode.GDAnswerObjects1= [];
gdjs.Triangular_32PrismCode.GDAnswerObjects2= [];
gdjs.Triangular_32PrismCode.GDunitObjects1= [];
gdjs.Triangular_32PrismCode.GDunitObjects2= [];
gdjs.Triangular_32PrismCode.GDBackNewButtonObjects1= [];
gdjs.Triangular_32PrismCode.GDBackNewButtonObjects2= [];
gdjs.Triangular_32PrismCode.GDControlsObjects1= [];
gdjs.Triangular_32PrismCode.GDControlsObjects2= [];
gdjs.Triangular_32PrismCode.GDAnswerButtonObjects1= [];
gdjs.Triangular_32PrismCode.GDAnswerButtonObjects2= [];


gdjs.Triangular_32PrismCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Length"), gdjs.Triangular_32PrismCode.GDLengthObjects1);
gdjs.copyArray(runtimeScene.getObjects("Width"), gdjs.Triangular_32PrismCode.GDWidthObjects1);
gdjs.copyArray(runtimeScene.getObjects("height"), gdjs.Triangular_32PrismCode.GDheightObjects1);
gdjs.Triangular_32PrismCode.GDAnswerButtonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
{isConditionTrue_1 = ((gdjs.evtTools.common.toNumber(((( gdjs.Triangular_32PrismCode.GDheightObjects1.length === 0 ) ? "" :gdjs.Triangular_32PrismCode.GDheightObjects1[0].getBehavior("Text").getText())))) > 0);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = ((gdjs.evtTools.common.toNumber(((( gdjs.Triangular_32PrismCode.GDWidthObjects1.length === 0 ) ? "" :gdjs.Triangular_32PrismCode.GDWidthObjects1[0].getBehavior("Text").getText())))) > 0);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{isConditionTrue_1 = ((gdjs.evtTools.common.toNumber(((( gdjs.Triangular_32PrismCode.GDLengthObjects1.length === 0 ) ? "" :gdjs.Triangular_32PrismCode.GDLengthObjects1[0].getBehavior("Text").getText())))) > 0);
}
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{gdjs.Triangular_32PrismCode.GDAnswerButtonObjects1_2final.length = 0;
let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
isConditionTrue_2 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("AnswerButton"), gdjs.Triangular_32PrismCode.GDAnswerButtonObjects2);
for (var i = 0, k = 0, l = gdjs.Triangular_32PrismCode.GDAnswerButtonObjects2.length;i<l;++i) {
    if ( gdjs.Triangular_32PrismCode.GDAnswerButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_2 = true;
        gdjs.Triangular_32PrismCode.GDAnswerButtonObjects2[k] = gdjs.Triangular_32PrismCode.GDAnswerButtonObjects2[i];
        ++k;
    }
}
gdjs.Triangular_32PrismCode.GDAnswerButtonObjects2.length = k;
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
    for (let j = 0, jLen = gdjs.Triangular_32PrismCode.GDAnswerButtonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Triangular_32PrismCode.GDAnswerButtonObjects1_2final.indexOf(gdjs.Triangular_32PrismCode.GDAnswerButtonObjects2[j]) === -1 )
            gdjs.Triangular_32PrismCode.GDAnswerButtonObjects1_2final.push(gdjs.Triangular_32PrismCode.GDAnswerButtonObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Triangular_32PrismCode.GDAnswerButtonObjects1_2final, gdjs.Triangular_32PrismCode.GDAnswerButtonObjects1);
}
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Answer"), gdjs.Triangular_32PrismCode.GDAnswerObjects1);
/* Reuse gdjs.Triangular_32PrismCode.GDLengthObjects1 */
gdjs.copyArray(runtimeScene.getObjects("TriangularPrism"), gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1);
/* Reuse gdjs.Triangular_32PrismCode.GDWidthObjects1 */
/* Reuse gdjs.Triangular_32PrismCode.GDheightObjects1 */
gdjs.copyArray(runtimeScene.getObjects("unit"), gdjs.Triangular_32PrismCode.GDunitObjects1);
{for(var i = 0, len = gdjs.Triangular_32PrismCode.GDAnswerObjects1.length ;i < len;++i) {
    gdjs.Triangular_32PrismCode.GDAnswerObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.common.toNumber(((( gdjs.Triangular_32PrismCode.GDheightObjects1.length === 0 ) ? "" :gdjs.Triangular_32PrismCode.GDheightObjects1[0].getBehavior("Text").getText()))) * gdjs.evtTools.common.toNumber((( gdjs.Triangular_32PrismCode.GDWidthObjects1.length === 0 ) ? "" :gdjs.Triangular_32PrismCode.GDWidthObjects1[0].getBehavior("Text").getText())) * gdjs.evtTools.common.toNumber(((( gdjs.Triangular_32PrismCode.GDLengthObjects1.length === 0 ) ? "" :gdjs.Triangular_32PrismCode.GDLengthObjects1[0].getBehavior("Text").getText()))) / 2) + (( gdjs.Triangular_32PrismCode.GDunitObjects1.length === 0 ) ? "" :gdjs.Triangular_32PrismCode.GDunitObjects1[0].getBehavior("Text").getText()) + ((gdjs.Triangular_32PrismCode.GDunitObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Triangular_32PrismCode.GDunitObjects1[0].getVariables()).getFromIndex(0).getAsString());
}
}{for(var i = 0, len = gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1.length ;i < len;++i) {
    gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1[i].getBehavior("Resizable").setSize(gdjs.evtTools.common.toNumber(((( gdjs.Triangular_32PrismCode.GDWidthObjects1.length === 0 ) ? "" :gdjs.Triangular_32PrismCode.GDWidthObjects1[0].getBehavior("Text").getText()))) * 10, gdjs.evtTools.common.toNumber(((( gdjs.Triangular_32PrismCode.GDheightObjects1.length === 0 ) ? "" :gdjs.Triangular_32PrismCode.GDheightObjects1[0].getBehavior("Text").getText()))) * 10);
}
}{for(var i = 0, len = gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1.length ;i < len;++i) {
    gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1[i].getBehavior("Object3D").setDepth(gdjs.evtTools.common.toNumber((( gdjs.Triangular_32PrismCode.GDLengthObjects1.length === 0 ) ? "" :gdjs.Triangular_32PrismCode.GDLengthObjects1[0].getBehavior("Text").getText())) * 10);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TriangularPrism"), gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1);
{for(var i = 0, len = gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1.length ;i < len;++i) {
    gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1[i].getBehavior("Object3D").turnAroundX(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TriangularPrism"), gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1);
{for(var i = 0, len = gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1.length ;i < len;++i) {
    gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1[i].getBehavior("Object3D").turnAroundY(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TriangularPrism"), gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1);
{for(var i = 0, len = gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1.length ;i < len;++i) {
    gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1[i].getBehavior("Object3D").turnAroundY(-(3));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TriangularPrism"), gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1);
{for(var i = 0, len = gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1.length ;i < len;++i) {
    gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1[i].getBehavior("Object3D").turnAroundX(-(3));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Dash");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TriangularPrism"), gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1);
{for(var i = 0, len = gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1.length ;i < len;++i) {
    gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1[i].getBehavior("Scale").setScaleX(gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1[i].getBehavior("Scale").getScaleX() / (1.009));
}
}{for(var i = 0, len = gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1.length ;i < len;++i) {
    gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1[i].getBehavior("Scale").setScaleY(gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1[i].getBehavior("Scale").getScaleY() / (1.009));
}
}{for(var i = 0, len = gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1.length ;i < len;++i) {
    gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1[i].getBehavior("Object3D").setScaleZ(gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1[i].getBehavior("Object3D").getScaleZ() / (1.009));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Equal");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TriangularPrism"), gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1);
{for(var i = 0, len = gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1.length ;i < len;++i) {
    gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1[i].getBehavior("Scale").setScaleX(gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1[i].getBehavior("Scale").getScaleX() * (1.009));
}
}{for(var i = 0, len = gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1.length ;i < len;++i) {
    gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1[i].getBehavior("Object3D").setScaleZ(gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1[i].getBehavior("Object3D").getScaleZ() * (1.009));
}
}{for(var i = 0, len = gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1.length ;i < len;++i) {
    gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1[i].getBehavior("Scale").setScaleY(gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1[i].getBehavior("Scale").getScaleY() * (1.009));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LShift");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TriangularPrism"), gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1);
{for(var i = 0, len = gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1.length ;i < len;++i) {
    gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1[i].getBehavior("Object3D").turnAroundZ(3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LControl");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TriangularPrism"), gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1);
{for(var i = 0, len = gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1.length ;i < len;++i) {
    gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1[i].getBehavior("Object3D").turnAroundZ(-(3));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BackNewButton"), gdjs.Triangular_32PrismCode.GDBackNewButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Triangular_32PrismCode.GDBackNewButtonObjects1.length;i<l;++i) {
    if ( gdjs.Triangular_32PrismCode.GDBackNewButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Triangular_32PrismCode.GDBackNewButtonObjects1[k] = gdjs.Triangular_32PrismCode.GDBackNewButtonObjects1[i];
        ++k;
    }
}
gdjs.Triangular_32PrismCode.GDBackNewButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


};

gdjs.Triangular_32PrismCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1.length = 0;
gdjs.Triangular_32PrismCode.GDTriangularPrismObjects2.length = 0;
gdjs.Triangular_32PrismCode.GDheightObjects1.length = 0;
gdjs.Triangular_32PrismCode.GDheightObjects2.length = 0;
gdjs.Triangular_32PrismCode.GDWidthObjects1.length = 0;
gdjs.Triangular_32PrismCode.GDWidthObjects2.length = 0;
gdjs.Triangular_32PrismCode.GDLengthObjects1.length = 0;
gdjs.Triangular_32PrismCode.GDLengthObjects2.length = 0;
gdjs.Triangular_32PrismCode.GDAnswerObjects1.length = 0;
gdjs.Triangular_32PrismCode.GDAnswerObjects2.length = 0;
gdjs.Triangular_32PrismCode.GDunitObjects1.length = 0;
gdjs.Triangular_32PrismCode.GDunitObjects2.length = 0;
gdjs.Triangular_32PrismCode.GDBackNewButtonObjects1.length = 0;
gdjs.Triangular_32PrismCode.GDBackNewButtonObjects2.length = 0;
gdjs.Triangular_32PrismCode.GDControlsObjects1.length = 0;
gdjs.Triangular_32PrismCode.GDControlsObjects2.length = 0;
gdjs.Triangular_32PrismCode.GDAnswerButtonObjects1.length = 0;
gdjs.Triangular_32PrismCode.GDAnswerButtonObjects2.length = 0;

gdjs.Triangular_32PrismCode.eventsList0(runtimeScene);
gdjs.Triangular_32PrismCode.GDTriangularPrismObjects1.length = 0;
gdjs.Triangular_32PrismCode.GDTriangularPrismObjects2.length = 0;
gdjs.Triangular_32PrismCode.GDheightObjects1.length = 0;
gdjs.Triangular_32PrismCode.GDheightObjects2.length = 0;
gdjs.Triangular_32PrismCode.GDWidthObjects1.length = 0;
gdjs.Triangular_32PrismCode.GDWidthObjects2.length = 0;
gdjs.Triangular_32PrismCode.GDLengthObjects1.length = 0;
gdjs.Triangular_32PrismCode.GDLengthObjects2.length = 0;
gdjs.Triangular_32PrismCode.GDAnswerObjects1.length = 0;
gdjs.Triangular_32PrismCode.GDAnswerObjects2.length = 0;
gdjs.Triangular_32PrismCode.GDunitObjects1.length = 0;
gdjs.Triangular_32PrismCode.GDunitObjects2.length = 0;
gdjs.Triangular_32PrismCode.GDBackNewButtonObjects1.length = 0;
gdjs.Triangular_32PrismCode.GDBackNewButtonObjects2.length = 0;
gdjs.Triangular_32PrismCode.GDControlsObjects1.length = 0;
gdjs.Triangular_32PrismCode.GDControlsObjects2.length = 0;
gdjs.Triangular_32PrismCode.GDAnswerButtonObjects1.length = 0;
gdjs.Triangular_32PrismCode.GDAnswerButtonObjects2.length = 0;


return;

}

gdjs['Triangular_32PrismCode'] = gdjs.Triangular_32PrismCode;
